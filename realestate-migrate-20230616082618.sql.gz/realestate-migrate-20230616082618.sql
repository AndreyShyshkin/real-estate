# Миграция MySQL базы данных WordPress
#
# Сформирован: Friday 16. June 2023 08:26 UTC
# Адрес сайта: localhost
# База данных: `real-estate`
# URL: //realestate.000.pe
# Path: D:\\OSPanel\\domains\\real-estate
# Tables: re_commentmeta, re_comments, re_links, re_options, re_postmeta, re_posts, re_term_relationships, re_term_taxonomy, re_termmeta, re_terms, re_user_registration_sessions, re_usermeta, re_users
# Table Prefix: re_
# Post Types: revision, acf-field, acf-field-group, acf-post-type, attachment, nav_menu_item, page, post, property, user_registration
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Удалить любую существующую таблицу `re_commentmeta`
#

DROP TABLE IF EXISTS `re_commentmeta`;


#
# Структура таблицы `re_commentmeta`
#

CREATE TABLE `re_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_commentmeta`
#

#
# Конец содержимого данных таблицы `re_commentmeta`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_comments`
#

DROP TABLE IF EXISTS `re_comments`;


#
# Структура таблицы `re_comments`
#

CREATE TABLE `re_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_comments`
#
INSERT INTO `re_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Комментатор WordPress', 'wapuu@wordpress.example', 'https://ru.wordpress.org/', '', '2023-05-29 12:20:15', '2023-05-29 09:20:15', 'Привет! Это комментарий.\nЧтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.\nАватары авторов комментариев загружаются с сервиса <a href="https://ru.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# Конец содержимого данных таблицы `re_comments`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_links`
#

DROP TABLE IF EXISTS `re_links`;


#
# Структура таблицы `re_links`
#

CREATE TABLE `re_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_links`
#

#
# Конец содержимого данных таблицы `re_links`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_options`
#

DROP TABLE IF EXISTS `re_options`;


#
# Структура таблицы `re_options`
#

CREATE TABLE `re_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=770 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_options`
#
INSERT INTO `re_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://realestate.000.pe', 'yes'),
(2, 'home', 'http://realestate.000.pe', 'yes'),
(3, 'blogname', 'Real Estate', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '1', 'yes'),
(6, 'admin_email', 'shyshkinandrey06@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd.m.Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'd.m.Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:5:{i:0;s:21:"polylang/polylang.php";i:1;s:30:"advanced-custom-fields/acf.php";i:2;s:19:"jetpack/jetpack.php";i:3;s:33:"theme-my-login/theme-my-login.php";i:5;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '3', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'realestate', 'yes'),
(41, 'stylesheet', 'realestate', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '21', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1700904010', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '53496', 'yes'),
(100, 're_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:79:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:24:"manage_user_registration";b:1;s:22:"edit_user_registration";b:1;s:22:"read_user_registration";b:1;s:24:"delete_user_registration";b:1;s:23:"edit_user_registrations";b:1;s:30:"edit_others_user_registrations";b:1;s:26:"publish_user_registrations";b:1;s:31:"read_private_user_registrations";b:1;s:25:"delete_user_registrations";b:1;s:33:"delete_private_user_registrations";b:1;s:35:"delete_published_user_registrations";b:1;s:32:"delete_others_user_registrations";b:1;s:31:"edit_private_user_registrations";b:1;s:33:"edit_published_user_registrations";b:1;s:30:"manage_user_registration_terms";b:1;s:28:"edit_user_registration_terms";b:1;s:30:"delete_user_registration_terms";b:1;s:30:"assign_user_registration_terms";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(101, 'fresh_site', '0', 'yes') ;
INSERT INTO `re_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(102, 'WPLANG', 'ru_RU', 'yes'),
(103, 'user_count', '2', 'no'),
(104, 'widget_block', 'a:7:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:198:"<!-- wp:group -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Свежие записи</h2>\n<!-- /wp:heading -->\n\n<!-- wp:latest-posts /--></div>\n<!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:278:"<!-- wp:group -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Свежие комментарии</h2>\n<!-- /wp:heading -->\n\n<!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div>\n<!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:181:"<!-- wp:group -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Архивы</h2>\n<!-- /wp:heading -->\n\n<!-- wp:archives /--></div>\n<!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:185:"<!-- wp:group -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Рубрики</h2>\n<!-- /wp:heading -->\n\n<!-- wp:categories /--></div>\n<!-- /wp:group -->";}i:7;a:1:{s:7:"content";s:22:"<!-- wp:shortcode /-->";}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:4:{i:0;s:7:"block-7";i:1;s:16:"theme-my-login-3";i:2;s:16:"theme-my-login-4";i:3;s:16:"theme-my-login-5";}s:9:"sidebar-1";a:6:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";i:5;s:16:"theme-my-login-2";}s:13:"array_version";i:3;}', 'yes'),
(106, 'cron', 'a:9:{i:1686906388;a:2:{s:20:"jetpack_v2_heartbeat";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:20:"jetpack_clean_nonces";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1686907216;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1686907217;a:5:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1686907231;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1686907232;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1686907234;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1687252817;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1688115894;a:1:{s:46:"user_registration_usage_stats_scheduled_events";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:8:"biweekly";s:4:"args";a:0:{}s:8:"interval";i:1296000;}}}s:7:"version";i:2;}', 'yes'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(122, 'recovery_keys', 'a:0:{}', 'yes'),
(123, 'theme_mods_twentytwentythree', 'a:4:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1685635857;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}s:19:"wp_classic_sidebars";a:0:{}s:18:"nav_menu_locations";a:0:{}}', 'yes'),
(125, 'https_detection_errors', 'a:1:{s:23:"ssl_verification_failed";a:1:{i:0;s:38:"Проверка SSL неудачна.";}}', 'yes'),
(144, 'can_compress_scripts', '1', 'no'),
(157, 'finished_updating_comment_type', '1', 'yes'),
(165, 'current_theme', 'RealEstate', 'yes'),
(166, 'theme_mods_realestate', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:4:{s:11:"header-menu";i:2;s:11:"footer-menu";i:3;s:18:"social-footer-menu";i:4;s:6:"menu-1";i:0;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1685635771;s:4:"data";a:1:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}}}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(167, 'theme_switched', '', 'yes'),
(211, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(273, 'recently_activated', 'a:4:{s:45:"user-submitted-posts/user-submitted-posts.php";i:1686820677;s:39:"user-registration/user-registration.php";i:1686819929;s:33:"wps-hide-login/wps-hide-login.php";i:1686769500;s:41:"navz-photo-gallery/navz-photo-gallery.php";i:1686653564;}', 'yes'),
(278, 'acf_version', '6.1.6', 'yes'),
(294, 'polylang', 'a:15:{s:7:"browser";i:0;s:7:"rewrite";i:1;s:12:"hide_default";i:1;s:10:"force_lang";i:1;s:13:"redirect_lang";i:0;s:13:"media_support";b:1;s:9:"uninstall";i:0;s:4:"sync";a:0:{}s:10:"post_types";a:1:{i:0;s:8:"property";}s:10:"taxonomies";a:2:{i:0;s:6:"cities";i:1;s:8:"features";}s:7:"domains";a:0:{}s:7:"version";s:5:"3.4.2";s:16:"first_activation";i:1686406865;s:12:"default_lang";s:2:"uk";s:9:"nav_menus";a:1:{s:10:"realestate";a:4:{s:11:"header-menu";a:2:{s:2:"uk";i:2;s:2:"en";i:2;}s:11:"footer-menu";a:2:{s:2:"uk";i:3;s:2:"en";i:3;}s:18:"social-footer-menu";a:2:{s:2:"uk";i:4;s:2:"en";i:4;}s:6:"menu-1";a:2:{s:2:"uk";i:0;s:2:"en";i:0;}}}}', 'yes'),
(295, 'polylang_wpml_strings', 'a:0:{}', 'yes'),
(296, 'widget_polylang', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(301, 'category_children', 'a:0:{}', 'yes'),
(305, 'pll_dismissed_notices', 'a:1:{i:0;s:6:"wizard";}', 'yes'),
(321, 'rewrite_rules', 'a:250:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:53:"^(en)/wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:92:"index.php?lang=$matches[1]&sitemap=$matches[2]&sitemap-subtype=$matches[3]&paged=$matches[4]";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:39:"^(en)/wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:64:"index.php?lang=$matches[1]&sitemap=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:12:"dashboard/?$";s:26:"index.php?action=dashboard";s:8:"login/?$";s:22:"index.php?action=login";s:9:"logout/?$";s:23:"index.php?action=logout";s:11:"register/?$";s:25:"index.php?action=register";s:15:"lostpassword/?$";s:29:"index.php?action=lostpassword";s:12:"resetpass/?$";s:26:"index.php?action=resetpass";s:16:"confirmaction/?$";s:30:"index.php?action=confirmaction";s:18:"(en)/properties/?$";s:45:"index.php?lang=$matches[1]&post_type=property";s:13:"properties/?$";s:36:"index.php?lang=uk&post_type=property";s:48:"(en)/properties/feed/(feed|rdf|rss|rss2|atom)/?$";s:62:"index.php?lang=$matches[1]&post_type=property&feed=$matches[2]";s:43:"properties/feed/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?lang=uk&post_type=property&feed=$matches[1]";s:43:"(en)/properties/(feed|rdf|rss|rss2|atom)/?$";s:62:"index.php?lang=$matches[1]&post_type=property&feed=$matches[2]";s:38:"properties/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?lang=uk&post_type=property&feed=$matches[1]";s:35:"(en)/properties/page/([0-9]{1,})/?$";s:63:"index.php?lang=$matches[1]&post_type=property&paged=$matches[2]";s:30:"properties/page/([0-9]{1,})/?$";s:54:"index.php?lang=uk&post_type=property&paged=$matches[1]";s:52:"(en)/category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?lang=$matches[1]&category_name=$matches[2]&feed=$matches[3]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:47:"(en)/category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?lang=$matches[1]&category_name=$matches[2]&feed=$matches[3]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:28:"(en)/category/(.+?)/embed/?$";s:63:"index.php?lang=$matches[1]&category_name=$matches[2]&embed=true";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:40:"(en)/category/(.+?)/page/?([0-9]{1,})/?$";s:70:"index.php?lang=$matches[1]&category_name=$matches[2]&paged=$matches[3]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:22:"(en)/category/(.+?)/?$";s:52:"index.php?lang=$matches[1]&category_name=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:49:"(en)/tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:59:"index.php?lang=$matches[1]&tag=$matches[2]&feed=$matches[3]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:44:"(en)/tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:59:"index.php?lang=$matches[1]&tag=$matches[2]&feed=$matches[3]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:25:"(en)/tag/([^/]+)/embed/?$";s:53:"index.php?lang=$matches[1]&tag=$matches[2]&embed=true";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:37:"(en)/tag/([^/]+)/page/?([0-9]{1,})/?$";s:60:"index.php?lang=$matches[1]&tag=$matches[2]&paged=$matches[3]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:19:"(en)/tag/([^/]+)/?$";s:42:"index.php?lang=$matches[1]&tag=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:50:"(en)/type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:67:"index.php?lang=$matches[1]&post_format=$matches[2]&feed=$matches[3]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:58:"index.php?lang=uk&post_format=$matches[1]&feed=$matches[2]";s:45:"(en)/type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:67:"index.php?lang=$matches[1]&post_format=$matches[2]&feed=$matches[3]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:58:"index.php?lang=uk&post_format=$matches[1]&feed=$matches[2]";s:26:"(en)/type/([^/]+)/embed/?$";s:61:"index.php?lang=$matches[1]&post_format=$matches[2]&embed=true";s:21:"type/([^/]+)/embed/?$";s:52:"index.php?lang=uk&post_format=$matches[1]&embed=true";s:38:"(en)/type/([^/]+)/page/?([0-9]{1,})/?$";s:68:"index.php?lang=$matches[1]&post_format=$matches[2]&paged=$matches[3]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:59:"index.php?lang=uk&post_format=$matches[1]&paged=$matches[2]";s:20:"(en)/type/([^/]+)/?$";s:50:"index.php?lang=$matches[1]&post_format=$matches[2]";s:15:"type/([^/]+)/?$";s:41:"index.php?lang=uk&post_format=$matches[1]";s:50:"(en)/City/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:62:"index.php?lang=$matches[1]&cities=$matches[2]&feed=$matches[3]";s:45:"City/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?cities=$matches[1]&feed=$matches[2]";s:45:"(en)/City/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:62:"index.php?lang=$matches[1]&cities=$matches[2]&feed=$matches[3]";s:40:"City/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?cities=$matches[1]&feed=$matches[2]";s:26:"(en)/City/([^/]+)/embed/?$";s:56:"index.php?lang=$matches[1]&cities=$matches[2]&embed=true";s:21:"City/([^/]+)/embed/?$";s:39:"index.php?cities=$matches[1]&embed=true";s:38:"(en)/City/([^/]+)/page/?([0-9]{1,})/?$";s:63:"index.php?lang=$matches[1]&cities=$matches[2]&paged=$matches[3]";s:33:"City/([^/]+)/page/?([0-9]{1,})/?$";s:46:"index.php?cities=$matches[1]&paged=$matches[2]";s:20:"(en)/City/([^/]+)/?$";s:45:"index.php?lang=$matches[1]&cities=$matches[2]";s:15:"City/([^/]+)/?$";s:28:"index.php?cities=$matches[1]";s:54:"(en)/features/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?lang=$matches[1]&features=$matches[2]&feed=$matches[3]";s:49:"features/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?features=$matches[1]&feed=$matches[2]";s:49:"(en)/features/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?lang=$matches[1]&features=$matches[2]&feed=$matches[3]";s:44:"features/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?features=$matches[1]&feed=$matches[2]";s:30:"(en)/features/([^/]+)/embed/?$";s:58:"index.php?lang=$matches[1]&features=$matches[2]&embed=true";s:25:"features/([^/]+)/embed/?$";s:41:"index.php?features=$matches[1]&embed=true";s:42:"(en)/features/([^/]+)/page/?([0-9]{1,})/?$";s:65:"index.php?lang=$matches[1]&features=$matches[2]&paged=$matches[3]";s:37:"features/([^/]+)/page/?([0-9]{1,})/?$";s:48:"index.php?features=$matches[1]&paged=$matches[2]";s:24:"(en)/features/([^/]+)/?$";s:47:"index.php?lang=$matches[1]&features=$matches[2]";s:19:"features/([^/]+)/?$";s:30:"index.php?features=$matches[1]";s:43:"(en)/properties/[^/]+/attachment/([^/]+)/?$";s:49:"index.php?lang=$matches[1]&attachment=$matches[2]";s:38:"properties/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:53:"(en)/properties/[^/]+/attachment/([^/]+)/trackback/?$";s:54:"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1";s:48:"properties/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:73:"(en)/properties/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:68:"properties/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:68:"(en)/properties/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:63:"properties/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:68:"(en)/properties/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:67:"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]";s:63:"properties/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:49:"(en)/properties/[^/]+/attachment/([^/]+)/embed/?$";s:60:"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true";s:44:"properties/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:32:"(en)/properties/([^/]+)/embed/?$";s:58:"index.php?lang=$matches[1]&property=$matches[2]&embed=true";s:27:"properties/([^/]+)/embed/?$";s:41:"index.php?property=$matches[1]&embed=true";s:36:"(en)/properties/([^/]+)/trackback/?$";s:52:"index.php?lang=$matches[1]&property=$matches[2]&tb=1";s:31:"properties/([^/]+)/trackback/?$";s:35:"index.php?property=$matches[1]&tb=1";s:56:"(en)/properties/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?lang=$matches[1]&property=$matches[2]&feed=$matches[3]";s:51:"properties/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?property=$matches[1]&feed=$matches[2]";s:51:"(en)/properties/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?lang=$matches[1]&property=$matches[2]&feed=$matches[3]";s:46:"properties/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?property=$matches[1]&feed=$matches[2]";s:44:"(en)/properties/([^/]+)/page/?([0-9]{1,})/?$";s:65:"index.php?lang=$matches[1]&property=$matches[2]&paged=$matches[3]";s:39:"properties/([^/]+)/page/?([0-9]{1,})/?$";s:48:"index.php?property=$matches[1]&paged=$matches[2]";s:51:"(en)/properties/([^/]+)/comment-page-([0-9]{1,})/?$";s:65:"index.php?lang=$matches[1]&property=$matches[2]&cpage=$matches[3]";s:46:"properties/([^/]+)/comment-page-([0-9]{1,})/?$";s:48:"index.php?property=$matches[1]&cpage=$matches[2]";s:40:"(en)/properties/([^/]+)(?:/([0-9]+))?/?$";s:64:"index.php?lang=$matches[1]&property=$matches[2]&page=$matches[3]";s:35:"properties/([^/]+)(?:/([0-9]+))?/?$";s:47:"index.php?property=$matches[1]&page=$matches[2]";s:32:"(en)/properties/[^/]+/([^/]+)/?$";s:49:"index.php?lang=$matches[1]&attachment=$matches[2]";s:27:"properties/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"(en)/properties/[^/]+/([^/]+)/trackback/?$";s:54:"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1";s:37:"properties/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"(en)/properties/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:57:"properties/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"(en)/properties/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:52:"properties/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"(en)/properties/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:67:"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]";s:52:"properties/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"(en)/properties/[^/]+/([^/]+)/embed/?$";s:60:"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true";s:33:"properties/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:37:"(en)/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?lang=$matches[1]&&feed=$matches[2]";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:35:"index.php?lang=uk&&feed=$matches[1]";s:32:"(en)/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?lang=$matches[1]&&feed=$matches[2]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:35:"index.php?lang=uk&&feed=$matches[1]";s:13:"(en)/embed/?$";s:38:"index.php?lang=$matches[1]&&embed=true";s:8:"embed/?$";s:29:"index.php?lang=uk&&embed=true";s:25:"(en)/page/?([0-9]{1,})/?$";s:45:"index.php?lang=$matches[1]&&paged=$matches[2]";s:20:"page/?([0-9]{1,})/?$";s:36:"index.php?lang=uk&&paged=$matches[1]";s:32:"(en)/comment-page-([0-9]{1,})/?$";s:56:"index.php?lang=$matches[1]&&page_id=53&cpage=$matches[2]";s:27:"comment-page-([0-9]{1,})/?$";s:47:"index.php?lang=uk&&page_id=53&cpage=$matches[1]";s:7:"(en)/?$";s:26:"index.php?lang=$matches[1]";s:46:"(en)/comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:59:"index.php?lang=$matches[1]&&feed=$matches[2]&withcomments=1";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?lang=uk&&feed=$matches[1]&withcomments=1";s:41:"(en)/comments/(feed|rdf|rss|rss2|atom)/?$";s:59:"index.php?lang=$matches[1]&&feed=$matches[2]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?lang=uk&&feed=$matches[1]&withcomments=1";s:22:"(en)/comments/embed/?$";s:38:"index.php?lang=$matches[1]&&embed=true";s:17:"comments/embed/?$";s:29:"index.php?lang=uk&&embed=true";s:49:"(en)/search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:57:"index.php?lang=$matches[1]&s=$matches[2]&feed=$matches[3]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?lang=uk&s=$matches[1]&feed=$matches[2]";s:44:"(en)/search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:57:"index.php?lang=$matches[1]&s=$matches[2]&feed=$matches[3]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?lang=uk&s=$matches[1]&feed=$matches[2]";s:25:"(en)/search/(.+)/embed/?$";s:51:"index.php?lang=$matches[1]&s=$matches[2]&embed=true";s:20:"search/(.+)/embed/?$";s:42:"index.php?lang=uk&s=$matches[1]&embed=true";s:37:"(en)/search/(.+)/page/?([0-9]{1,})/?$";s:58:"index.php?lang=$matches[1]&s=$matches[2]&paged=$matches[3]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:49:"index.php?lang=uk&s=$matches[1]&paged=$matches[2]";s:19:"(en)/search/(.+)/?$";s:40:"index.php?lang=$matches[1]&s=$matches[2]";s:14:"search/(.+)/?$";s:31:"index.php?lang=uk&s=$matches[1]";s:52:"(en)/author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:67:"index.php?lang=$matches[1]&author_name=$matches[2]&feed=$matches[3]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:58:"index.php?lang=uk&author_name=$matches[1]&feed=$matches[2]";s:47:"(en)/author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:67:"index.php?lang=$matches[1]&author_name=$matches[2]&feed=$matches[3]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:58:"index.php?lang=uk&author_name=$matches[1]&feed=$matches[2]";s:28:"(en)/author/([^/]+)/embed/?$";s:61:"index.php?lang=$matches[1]&author_name=$matches[2]&embed=true";s:23:"author/([^/]+)/embed/?$";s:52:"index.php?lang=uk&author_name=$matches[1]&embed=true";s:40:"(en)/author/([^/]+)/page/?([0-9]{1,})/?$";s:68:"index.php?lang=$matches[1]&author_name=$matches[2]&paged=$matches[3]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:59:"index.php?lang=uk&author_name=$matches[1]&paged=$matches[2]";s:22:"(en)/author/([^/]+)/?$";s:50:"index.php?lang=$matches[1]&author_name=$matches[2]";s:17:"author/([^/]+)/?$";s:41:"index.php?lang=uk&author_name=$matches[1]";s:74:"(en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&feed=$matches[5]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:88:"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:69:"(en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&feed=$matches[5]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:88:"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:50:"(en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:91:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&embed=true";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:82:"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:62:"(en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:98:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&paged=$matches[5]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:89:"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:44:"(en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:80:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:71:"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:61:"(en)/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:81:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&feed=$matches[4]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:72:"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:56:"(en)/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:81:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&feed=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:72:"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:37:"(en)/([0-9]{4})/([0-9]{1,2})/embed/?$";s:75:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&embed=true";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:66:"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&embed=true";s:49:"(en)/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:82:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&paged=$matches[4]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:73:"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:31:"(en)/([0-9]{4})/([0-9]{1,2})/?$";s:64:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:55:"index.php?lang=uk&year=$matches[1]&monthnum=$matches[2]";s:48:"(en)/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:60:"index.php?lang=$matches[1]&year=$matches[2]&feed=$matches[3]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?lang=uk&year=$matches[1]&feed=$matches[2]";s:43:"(en)/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:60:"index.php?lang=$matches[1]&year=$matches[2]&feed=$matches[3]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?lang=uk&year=$matches[1]&feed=$matches[2]";s:24:"(en)/([0-9]{4})/embed/?$";s:54:"index.php?lang=$matches[1]&year=$matches[2]&embed=true";s:19:"([0-9]{4})/embed/?$";s:45:"index.php?lang=uk&year=$matches[1]&embed=true";s:36:"(en)/([0-9]{4})/page/?([0-9]{1,})/?$";s:61:"index.php?lang=$matches[1]&year=$matches[2]&paged=$matches[3]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:52:"index.php?lang=uk&year=$matches[1]&paged=$matches[2]";s:18:"(en)/([0-9]{4})/?$";s:43:"index.php?lang=$matches[1]&year=$matches[2]";s:13:"([0-9]{4})/?$";s:34:"index.php?lang=uk&year=$matches[1]";s:32:"(en)/.?.+?/attachment/([^/]+)/?$";s:49:"index.php?lang=$matches[1]&attachment=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"(en)/.?.+?/attachment/([^/]+)/trackback/?$";s:54:"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"(en)/.?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"(en)/.?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"(en)/.?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:67:"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"(en)/.?.+?/attachment/([^/]+)/embed/?$";s:60:"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:21:"(en)/(.?.+?)/embed/?$";s:58:"index.php?lang=$matches[1]&pagename=$matches[2]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:25:"(en)/(.?.+?)/trackback/?$";s:52:"index.php?lang=$matches[1]&pagename=$matches[2]&tb=1";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:45:"(en)/(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?lang=$matches[1]&pagename=$matches[2]&feed=$matches[3]";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:40:"(en)/(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?lang=$matches[1]&pagename=$matches[2]&feed=$matches[3]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:33:"(en)/(.?.+?)/page/?([0-9]{1,})/?$";s:65:"index.php?lang=$matches[1]&pagename=$matches[2]&paged=$matches[3]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:40:"(en)/(.?.+?)/comment-page-([0-9]{1,})/?$";s:65:"index.php?lang=$matches[1]&pagename=$matches[2]&cpage=$matches[3]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:29:"(en)/(.?.+?)(?:/([0-9]+))?/?$";s:64:"index.php?lang=$matches[1]&pagename=$matches[2]&page=$matches[3]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:32:"(en)/[^/]+/attachment/([^/]+)/?$";s:49:"index.php?lang=$matches[1]&attachment=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"(en)/[^/]+/attachment/([^/]+)/trackback/?$";s:54:"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"(en)/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"(en)/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"(en)/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:67:"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"(en)/[^/]+/attachment/([^/]+)/embed/?$";s:60:"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:21:"(en)/([^/]+)/embed/?$";s:54:"index.php?lang=$matches[1]&name=$matches[2]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:25:"(en)/([^/]+)/trackback/?$";s:48:"index.php?lang=$matches[1]&name=$matches[2]&tb=1";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:45:"(en)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:60:"index.php?lang=$matches[1]&name=$matches[2]&feed=$matches[3]";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:40:"(en)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:60:"index.php?lang=$matches[1]&name=$matches[2]&feed=$matches[3]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:33:"(en)/([^/]+)/page/?([0-9]{1,})/?$";s:61:"index.php?lang=$matches[1]&name=$matches[2]&paged=$matches[3]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:40:"(en)/([^/]+)/comment-page-([0-9]{1,})/?$";s:61:"index.php?lang=$matches[1]&name=$matches[2]&cpage=$matches[3]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:29:"(en)/([^/]+)(?:/([0-9]+))?/?$";s:60:"index.php?lang=$matches[1]&name=$matches[2]&page=$matches[3]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:21:"(en)/[^/]+/([^/]+)/?$";s:49:"index.php?lang=$matches[1]&attachment=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:31:"(en)/[^/]+/([^/]+)/trackback/?$";s:54:"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:51:"(en)/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"(en)/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"(en)/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:67:"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:27:"(en)/[^/]+/([^/]+)/embed/?$";s:60:"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(363, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1686903978;}', 'no'),
(422, 'cities_children', 'a:0:{}', 'yes'),
(455, 'widget_theme-my-login', 'a:5:{i:2;a:2:{s:6:"action";s:5:"login";s:10:"show_links";b:0;}i:3;a:2:{s:6:"action";s:5:"login";s:10:"show_links";b:0;}i:4;a:2:{s:6:"action";s:8:"register";s:10:"show_links";b:0;}i:5;a:2:{s:6:"action";s:12:"lostpassword";s:10:"show_links";b:1;}s:12:"_multiwidget";i:1;}', 'yes'),
(456, '_tml_installed_at', '1686779329', 'no'),
(457, '_tml_updated_at', '1686779329', 'no'),
(458, '_tml_version', '7.1.5', 'no'),
(461, 'tml_ajax', '', 'yes'),
(462, 'tml_login_type', 'default', 'yes'),
(463, 'tml_registration_type', 'default', 'yes'),
(464, 'tml_user_passwords', '1', 'yes'),
(465, 'tml_auto_login', '1', 'yes'),
(466, 'tml_dashboard_slug', 'dashboard', 'yes'),
(467, 'tml_login_slug', 'login', 'yes'),
(468, 'tml_logout_slug', 'logout', 'yes'),
(469, 'tml_register_slug', 'register', 'yes'),
(470, 'tml_lostpassword_slug', 'lostpassword', 'yes'),
(471, 'tml_resetpass_slug', 'resetpass', 'yes'),
(479, 'new_admin_email', 'shyshkinandrey06@gmail.com', 'yes'),
(542, 'user_registration_first_time_activation_flag', '', 'yes'),
(543, 'user_registration_default_form_page_id', '84', 'yes'),
(544, 'user_registration_version', '3.0.1', 'yes'),
(545, 'user_registration_db_version', '3.0.1', 'yes'),
(547, 'user_registration_updated_at', '2023-06-15', 'yes'),
(548, 'user_registration_captcha_setting_recaptcha_version', 'v2', 'yes'),
(549, 'user_registration_captcha_setting_invisible_recaptcha_v2', 'no', 'yes'),
(550, 'user_registration_enable_auto_generated_password_email', '1', 'yes'),
(551, 'user_registration_migration_version', '3.0', 'yes'),
(554, 'user_registration_admin_notices', 'a:0:{}', 'yes'),
(555, 'ur_profile_picture_migrated', '1', 'yes'),
(557, 'user_registration_registration_page_id', '85', 'yes'),
(558, 'user_registration_myaccount_page_id', '86', 'yes'),
(559, 'user_registration_general_setting_login_options', '0', 'yes'),
(560, 'user_registration_general_setting_disabled_user_roles', 'a:1:{i:3;s:10:"subscriber";}', 'yes'),
(561, 'user_registration_form_setting_enable_strong_password', 'no', 'yes'),
(562, 'user_registration_form_setting_default_user_role', 'subscriber', 'yes'),
(563, 'user_registration_my_account_layout', '0', 'yes'),
(564, 'user_registration_disable_profile_picture', 'no', 'yes'),
(565, 'user_registration_allow_usage_tracking', 'yes', 'yes'),
(567, 'user_registration_send_usage_last_run', '1686819896', 'yes'),
(568, 'user_registration_users_listing_viewed', '2023-06-15 12:05:05', 'yes'),
(571, 'jetpack_activated', '1', 'yes'),
(574, 'jetpack_activation_source', 'a:2:{i:0;s:8:"featured";i:1;N;}', 'yes'),
(575, 'jetpack_sync_settings_disable', '0', 'yes'),
(576, 'jetpack_options', 'a:4:{s:7:"version";s:17:"12.2.1:1686819987";s:11:"old_version";s:17:"12.2.1:1686819987";s:28:"fallback_no_verify_ssl_certs";i:0;s:9:"time_diff";i:0;}', 'yes'),
(579, 'jetpack_available_modules', 'a:1:{s:6:"12.2.1";a:46:{s:10:"action-bar";s:4:"11.4";s:8:"carousel";s:3:"1.5";s:13:"comment-likes";s:3:"5.1";s:8:"comments";s:3:"1.4";s:12:"contact-form";s:3:"1.3";s:9:"copy-post";s:3:"7.0";s:20:"custom-content-types";s:3:"3.1";s:10:"custom-css";s:3:"1.7";s:21:"enhanced-distribution";s:3:"1.2";s:16:"google-analytics";s:3:"4.5";s:12:"google-fonts";s:6:"10.8.0";s:19:"gravatar-hovercards";s:3:"1.1";s:15:"infinite-scroll";s:3:"2.0";s:8:"json-api";s:3:"1.9";s:5:"latex";s:3:"1.1";s:11:"lazy-images";s:5:"5.6.0";s:5:"likes";s:3:"2.2";s:8:"markdown";s:3:"2.8";s:9:"masterbar";s:3:"4.8";s:7:"monitor";s:3:"2.6";s:5:"notes";s:3:"1.9";s:10:"photon-cdn";s:3:"6.6";s:6:"photon";s:3:"2.0";s:13:"post-by-email";s:3:"2.0";s:9:"post-list";s:4:"11.3";s:7:"protect";s:3:"3.4";s:9:"publicize";s:3:"2.0";s:13:"related-posts";s:3:"2.9";s:6:"search";s:3:"5.0";s:9:"seo-tools";s:3:"4.4";s:10:"sharedaddy";s:3:"1.1";s:10:"shortcodes";s:3:"1.1";s:10:"shortlinks";s:3:"1.1";s:8:"sitemaps";s:3:"3.9";s:3:"sso";s:3:"2.6";s:5:"stats";s:3:"1.1";s:13:"subscriptions";s:3:"1.2";s:13:"tiled-gallery";s:3:"2.1";s:10:"vaultpress";s:5:"0:1.2";s:18:"verification-tools";s:3:"3.0";s:10:"videopress";s:3:"2.5";s:3:"waf";s:4:"10.9";s:17:"widget-visibility";s:3:"2.4";s:7:"widgets";s:3:"1.2";s:21:"woocommerce-analytics";s:3:"8.4";s:7:"wordads";s:5:"4.5.0";}}', 'yes'),
(581, 'jetpack_connection_active_plugins', 'a:1:{s:7:"jetpack";a:1:{s:4:"name";s:7:"Jetpack";}}', 'yes'),
(582, 'jetpack_testimonial', '0', 'yes'),
(584, 'do_activate', '0', 'yes'),
(589, 'sharing-options', 'a:1:{s:6:"global";a:5:{s:12:"button_style";s:9:"icon-text";s:13:"sharing_label";s:11:"Share this:";s:10:"open_links";s:4:"same";s:4:"show";a:2:{i:0;s:4:"post";i:1;s:4:"page";}s:6:"custom";a:0:{}}}', 'yes'),
(592, 'usp_options', 'a:82:{s:11:"usp_version";i:20230311;s:8:"usp_name";s:4:"show";s:9:"usp_email";s:4:"show";s:7:"usp_url";s:4:"show";s:9:"usp_title";s:4:"show";s:8:"usp_tags";s:4:"show";s:12:"usp_category";s:4:"show";s:11:"usp_content";s:4:"show";s:12:"custom_field";s:4:"show";s:14:"custom_field_2";s:4:"show";s:11:"usp_captcha";s:4:"show";s:13:"usp_recaptcha";s:4:"show";s:10:"usp_images";s:4:"show";s:16:"usp_form_version";s:7:"current";s:14:"usp_include_js";i:1;s:15:"usp_display_url";s:0:"";s:13:"usp_post_type";s:4:"post";s:15:"number-approved";i:-1;s:12:"redirect-url";s:0:"";s:15:"success-message";s:50:"Успех! Спасибо за ваш вклад.";s:13:"error-message";s:130:"Была допущена ошибка. Проверьте обязательные поля и повторите попытку.";s:16:"usp_form_content";s:0:"";s:6:"author";s:1:"1";s:16:"usp_email_alerts";i:1;s:17:"usp_email_address";s:26:"shyshkinandrey06@gmail.com";s:14:"usp_email_from";s:26:"shyshkinandrey06@gmail.com";s:19:"email_alert_subject";s:0:"";s:19:"email_alert_message";s:0:"";s:10:"categories";a:1:{i:0;s:1:"1";}s:14:"usp_use_cat_id";s:0:"";s:11:"custom_name";s:16:"usp_custom_field";s:12:"custom_label";s:43:"Пользовательское поле 1";s:13:"custom_name_2";s:18:"usp_custom_field_2";s:14:"custom_label_2";s:43:"Пользовательское поле 2";s:20:"custom_checkbox_name";s:19:"usp_custom_checkbox";s:19:"custom_checkbox_err";s:24:"Custom checkbox required";s:20:"custom_checkbox_text";s:25:"I agree the to the terms.";s:12:"usp_question";s:7:"1 + 1 =";s:12:"usp_response";s:1:"2";s:16:"recaptcha_public";s:0:"";s:17:"recaptcha_private";s:0:"";s:17:"recaptcha_version";s:1:"2";s:26:"usp_featured_image_default";s:0:"";s:14:"upload-message";s:86:"Пожалуйста, выберите изображения для загрузки.";s:15:"usp_add_another";s:0:"";s:10:"min-images";i:0;s:10:"max-images";i:1;s:15:"min-image-width";i:0;s:16:"min-image-height";i:0;s:15:"max-image-width";i:1500;s:16:"max-image-height";i:1500;s:19:"auto_display_images";s:7:"disable";s:17:"auto_image_markup";s:128:"<a href="%%full%%"><img src="%%thumb%%" width="%%width%%" height="%%height%%" alt="%%title%%" style="display:inline-block"></a> ";s:18:"auto_display_email";s:7:"disable";s:17:"auto_email_markup";s:71:"<p><a href="mailto:%%email%%">Электронная почта</a></p>";s:17:"auto_display_name";s:7:"disable";s:16:"auto_name_markup";s:17:"<p>%%author%%</p>";s:16:"auto_display_url";s:7:"disable";s:15:"auto_url_markup";s:43:"<p><a href="%%url%%">URL-адрес</a></p>";s:19:"auto_display_custom";s:7:"disable";s:18:"auto_custom_markup";s:60:"<p>%%custom_label%% : %%custom_name%% : %%custom_value%%</p>";s:21:"auto_display_custom_2";s:7:"disable";s:20:"auto_custom_markup_2";s:66:"<p>%%custom_label_2%% : %%custom_name_2%% : %%custom_value_2%%</p>";s:13:"version_alert";i:0;s:15:"default_options";i:0;s:10:"usp_casing";i:0;s:14:"usp_email_html";i:0;s:14:"usp_use_author";i:0;s:11:"usp_use_url";i:0;s:13:"usp_use_email";i:0;s:11:"usp_use_cat";i:0;s:17:"usp_existing_tags";i:0;s:19:"usp_richtext_editor";i:0;s:19:"usp_featured_images";i:0;s:16:"disable_required";i:0;s:13:"titles_unique";i:0;s:17:"enable_shortcodes";i:0;s:19:"disable_ip_tracking";i:0;s:15:"logged_in_users";i:0;s:14:"disable_author";i:0;s:15:"custom_checkbox";i:0;s:13:"multiple-cats";i:0;}', 'yes'),
(593, 'jetpack_content_post_details_date', '1', 'yes'),
(594, 'jetpack_content_post_details_categories', '1', 'yes'),
(595, 'jetpack_content_post_details_tags', '1', 'yes'),
(596, 'jetpack_content_post_details_author', '1', 'yes'),
(597, 'jetpack_content_post_details_comment', '1', 'yes') ;

#
# Конец содержимого данных таблицы `re_options`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_postmeta`
#

DROP TABLE IF EXISTS `re_postmeta`;


#
# Структура таблицы `re_postmeta`
#

CREATE TABLE `re_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=916 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_postmeta`
#
INSERT INTO `re_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_menu_item_type', 'custom'),
(4, 5, '_menu_item_menu_item_parent', '0'),
(5, 5, '_menu_item_object_id', '5'),
(6, 5, '_menu_item_object', 'custom'),
(7, 5, '_menu_item_target', ''),
(8, 5, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(9, 5, '_menu_item_xfn', ''),
(10, 5, '_menu_item_url', 'http://realestate.000.pe/'),
(20, 7, '_menu_item_type', 'post_type'),
(21, 7, '_menu_item_menu_item_parent', '0'),
(22, 7, '_menu_item_object_id', '2'),
(23, 7, '_menu_item_object', 'page'),
(24, 7, '_menu_item_target', ''),
(25, 7, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(26, 7, '_menu_item_xfn', ''),
(27, 7, '_menu_item_url', ''),
(28, 7, '_menu_item_orphaned', '1685784912'),
(29, 8, '_menu_item_type', 'post_type'),
(30, 8, '_menu_item_menu_item_parent', '0'),
(31, 8, '_menu_item_object_id', '2'),
(32, 8, '_menu_item_object', 'page'),
(33, 8, '_menu_item_target', ''),
(34, 8, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(35, 8, '_menu_item_xfn', ''),
(36, 8, '_menu_item_url', ''),
(37, 8, '_menu_item_orphaned', '1685784915'),
(38, 9, '_menu_item_type', 'post_type'),
(39, 9, '_menu_item_menu_item_parent', '0'),
(40, 9, '_menu_item_object_id', '2'),
(41, 9, '_menu_item_object', 'page'),
(42, 9, '_menu_item_target', ''),
(43, 9, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(44, 9, '_menu_item_xfn', ''),
(45, 9, '_menu_item_url', ''),
(46, 9, '_menu_item_orphaned', '1685784917'),
(47, 10, '_menu_item_type', 'custom'),
(48, 10, '_menu_item_menu_item_parent', '0'),
(49, 10, '_menu_item_object_id', '10'),
(50, 10, '_menu_item_object', 'custom'),
(51, 10, '_menu_item_target', ''),
(52, 10, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(53, 10, '_menu_item_xfn', ''),
(54, 10, '_menu_item_url', 'http://realestate.000.pe/properties/'),
(56, 11, '_menu_item_type', 'custom'),
(57, 11, '_menu_item_menu_item_parent', '0'),
(58, 11, '_menu_item_object_id', '11'),
(59, 11, '_menu_item_object', 'custom'),
(60, 11, '_menu_item_target', ''),
(61, 11, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(62, 11, '_menu_item_xfn', ''),
(63, 11, '_menu_item_url', '#'),
(65, 12, '_menu_item_type', 'custom'),
(66, 12, '_menu_item_menu_item_parent', '0'),
(67, 12, '_menu_item_object_id', '12'),
(68, 12, '_menu_item_object', 'custom'),
(69, 12, '_menu_item_target', ''),
(70, 12, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(71, 12, '_menu_item_xfn', ''),
(72, 12, '_menu_item_url', '#'),
(74, 13, '_menu_item_type', 'custom'),
(75, 13, '_menu_item_menu_item_parent', '0'),
(76, 13, '_menu_item_object_id', '13'),
(77, 13, '_menu_item_object', 'custom'),
(78, 13, '_menu_item_target', ''),
(79, 13, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(80, 13, '_menu_item_xfn', ''),
(81, 13, '_menu_item_url', '#'),
(83, 5, '_wp_old_date', '2023-06-02'),
(103, 17, '_edit_lock', '1685810338:1'),
(104, 17, '_wp_trash_meta_status', 'publish'),
(105, 17, '_wp_trash_meta_time', '1685810488'),
(106, 17, '_wp_desired_post_slug', '1234-2'),
(108, 3, '_edit_lock', '1685810474:1'),
(110, 21, '_edit_lock', '1686408783:1'),
(111, 21, '_wp_page_template', 'template-homepage.php'),
(112, 24, '_edit_last', '1'),
(113, 24, '_edit_lock', '1686843049:1'),
(114, 25, '_wp_attached_file', '2023/06/property-1.jpg'),
(115, 25, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:304;s:6:"height";i:248;s:4:"file";s:22:"2023/06/property-1.jpg";s:8:"filesize";i:23011;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:22:"property-1-300x245.jpg";s:5:"width";i:300;s:6:"height";i:245;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21979;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"property-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:12542;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:8:"N O_O ne";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1453321584";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(116, 24, '_thumbnail_id', '25'),
(117, 28, '_menu_item_type', 'custom'),
(118, 28, '_menu_item_menu_item_parent', '0'),
(119, 28, '_menu_item_object_id', '28'),
(120, 28, '_menu_item_object', 'custom'),
(121, 28, '_menu_item_target', ''),
(122, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(123, 28, '_menu_item_xfn', ''),
(124, 28, '_menu_item_url', '#'),
(125, 28, '_menu_item_orphaned', '1686068814'),
(126, 29, '_menu_item_type', 'custom'),
(127, 29, '_menu_item_menu_item_parent', '0'),
(128, 29, '_menu_item_object_id', '29'),
(129, 29, '_menu_item_object', 'custom'),
(130, 29, '_menu_item_target', ''),
(131, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(132, 29, '_menu_item_xfn', ''),
(133, 29, '_menu_item_url', '#'),
(134, 29, '_menu_item_orphaned', '1686068831') ;
INSERT INTO `re_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(135, 30, '_menu_item_type', 'custom'),
(136, 30, '_menu_item_menu_item_parent', '0'),
(137, 30, '_menu_item_object_id', '30'),
(138, 30, '_menu_item_object', 'custom'),
(139, 30, '_menu_item_target', ''),
(140, 30, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(141, 30, '_menu_item_xfn', ''),
(142, 30, '_menu_item_url', '#'),
(143, 30, '_menu_item_orphaned', '1686068849'),
(144, 31, '_menu_item_type', 'custom'),
(145, 31, '_menu_item_menu_item_parent', '0'),
(146, 31, '_menu_item_object_id', '31'),
(147, 31, '_menu_item_object', 'custom'),
(148, 31, '_menu_item_target', ''),
(149, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(150, 31, '_menu_item_xfn', ''),
(151, 31, '_menu_item_url', '#'),
(152, 31, '_menu_item_orphaned', '1686068862'),
(153, 32, '_menu_item_type', 'custom'),
(154, 32, '_menu_item_menu_item_parent', '0'),
(155, 32, '_menu_item_object_id', '32'),
(156, 32, '_menu_item_object', 'custom'),
(157, 32, '_menu_item_target', ''),
(158, 32, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(159, 32, '_menu_item_xfn', ''),
(160, 32, '_menu_item_url', '#'),
(161, 32, '_menu_item_orphaned', '1686068872'),
(162, 33, '_menu_item_type', 'custom'),
(163, 33, '_menu_item_menu_item_parent', '0'),
(164, 33, '_menu_item_object_id', '33'),
(165, 33, '_menu_item_object', 'custom'),
(166, 33, '_menu_item_target', ''),
(167, 33, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(168, 33, '_menu_item_xfn', ''),
(169, 33, '_menu_item_url', '#'),
(170, 33, '_menu_item_orphaned', '1686068880'),
(171, 34, '_menu_item_type', 'custom'),
(172, 34, '_menu_item_menu_item_parent', '0'),
(173, 34, '_menu_item_object_id', '34'),
(174, 34, '_menu_item_object', 'custom'),
(175, 34, '_menu_item_target', ''),
(176, 34, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(177, 34, '_menu_item_xfn', ''),
(178, 34, '_menu_item_url', '#'),
(180, 35, '_menu_item_type', 'custom'),
(181, 35, '_menu_item_menu_item_parent', '0'),
(182, 35, '_menu_item_object_id', '35'),
(183, 35, '_menu_item_object', 'custom'),
(184, 35, '_menu_item_target', ''),
(185, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(186, 35, '_menu_item_xfn', ''),
(187, 35, '_menu_item_url', '#'),
(189, 36, '_menu_item_type', 'custom'),
(190, 36, '_menu_item_menu_item_parent', '0'),
(191, 36, '_menu_item_object_id', '36'),
(192, 36, '_menu_item_object', 'custom'),
(193, 36, '_menu_item_target', ''),
(194, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(195, 36, '_menu_item_xfn', ''),
(196, 36, '_menu_item_url', '#'),
(198, 37, '_menu_item_type', 'custom'),
(199, 37, '_menu_item_menu_item_parent', '0'),
(200, 37, '_menu_item_object_id', '37'),
(201, 37, '_menu_item_object', 'custom'),
(202, 37, '_menu_item_target', ''),
(203, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(204, 37, '_menu_item_xfn', ''),
(205, 37, '_menu_item_url', '#'),
(207, 38, '_menu_item_type', 'custom'),
(208, 38, '_menu_item_menu_item_parent', '0'),
(209, 38, '_menu_item_object_id', '38'),
(210, 38, '_menu_item_object', 'custom'),
(211, 38, '_menu_item_target', ''),
(212, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(213, 38, '_menu_item_xfn', ''),
(214, 38, '_menu_item_url', '#'),
(216, 39, '_menu_item_type', 'custom'),
(217, 39, '_menu_item_menu_item_parent', '0'),
(218, 39, '_menu_item_object_id', '39'),
(219, 39, '_menu_item_object', 'custom'),
(220, 39, '_menu_item_target', ''),
(221, 39, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(222, 39, '_menu_item_xfn', ''),
(223, 39, '_menu_item_url', '#'),
(225, 40, '_menu_item_type', 'custom'),
(226, 40, '_menu_item_menu_item_parent', '0'),
(227, 40, '_menu_item_object_id', '40'),
(228, 40, '_menu_item_object', 'custom'),
(229, 40, '_menu_item_target', ''),
(230, 40, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(231, 40, '_menu_item_xfn', ''),
(232, 40, '_menu_item_url', '#'),
(234, 41, '_menu_item_type', 'custom'),
(235, 41, '_menu_item_menu_item_parent', '0'),
(236, 41, '_menu_item_object_id', '41'),
(237, 41, '_menu_item_object', 'custom'),
(238, 41, '_menu_item_target', ''),
(239, 41, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(240, 41, '_menu_item_xfn', ''),
(241, 41, '_menu_item_url', '#') ;
INSERT INTO `re_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(243, 42, '_menu_item_type', 'custom'),
(244, 42, '_menu_item_menu_item_parent', '0'),
(245, 42, '_menu_item_object_id', '42'),
(246, 42, '_menu_item_object', 'custom'),
(247, 42, '_menu_item_target', ''),
(248, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(249, 42, '_menu_item_xfn', ''),
(250, 42, '_menu_item_url', '#'),
(252, 43, '_menu_item_type', 'custom'),
(253, 43, '_menu_item_menu_item_parent', '0'),
(254, 43, '_menu_item_object_id', '43'),
(255, 43, '_menu_item_object', 'custom'),
(256, 43, '_menu_item_target', ''),
(257, 43, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(258, 43, '_menu_item_xfn', ''),
(259, 43, '_menu_item_url', '#'),
(260, 2, '_edit_lock', '1686819016:1'),
(261, 2, 'price', '2000'),
(262, 44, '_edit_last', '1'),
(263, 44, '_edit_lock', '1686837450:1'),
(264, 24, 'price', '300.000'),
(265, 24, '_price', 'field_64847c2feb7fc'),
(266, 24, 'area', '120'),
(267, 24, '_area', 'field_64847c59eb7fd'),
(268, 24, 'bath_room', '2'),
(269, 24, '_bath_room', 'field_64847f2f2ea18'),
(270, 24, 'bed_room', '1'),
(271, 24, '_bed_room', 'field_64847f562ea19'),
(272, 24, 'garage', '3'),
(273, 24, '_garage', 'field_64847f852ea1a'),
(274, 50, '_edit_lock', '1686405730:1'),
(275, 54, 'price', '300.000'),
(276, 54, 'area', '120'),
(277, 55, 'price', '300000'),
(278, 54, 'bath_room', '2'),
(279, 55, 'area', '120'),
(280, 54, 'bed_room', '1'),
(281, 55, 'bath_room', '2'),
(282, 54, 'garage', '3'),
(283, 55, 'bed_room', '1'),
(284, 54, '_thumbnail_id', '25'),
(285, 55, 'garage', '3'),
(286, 55, '_thumbnail_id', '25'),
(287, 55, '_edit_last', '1'),
(288, 55, '_price', 'field_64847c2feb7fc'),
(289, 55, '_area', 'field_64847c59eb7fd'),
(290, 55, '_bed_room', 'field_64847f562ea19'),
(291, 55, '_bath_room', 'field_64847f2f2ea18'),
(292, 55, '_garage', 'field_64847f852ea1a'),
(293, 55, '_edit_lock', '1686846055:1'),
(294, 56, '_menu_item_type', 'custom'),
(295, 56, '_menu_item_menu_item_parent', '0'),
(296, 56, '_menu_item_object_id', '56'),
(297, 56, '_menu_item_object', 'custom'),
(298, 56, '_menu_item_target', ''),
(299, 56, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(300, 56, '_menu_item_xfn', ''),
(301, 56, '_menu_item_url', '#pll_switcher'),
(303, 5, '_wp_old_date', '2023-06-03'),
(304, 10, '_wp_old_date', '2023-06-03'),
(305, 11, '_wp_old_date', '2023-06-03'),
(306, 12, '_wp_old_date', '2023-06-03'),
(307, 13, '_wp_old_date', '2023-06-03'),
(308, 56, '_pll_menu_item', 'a:6:{s:22:"hide_if_no_translation";i:0;s:12:"hide_current";i:1;s:10:"force_home";i:0;s:10:"show_flags";i:1;s:10:"show_names";i:1;s:8:"dropdown";i:0;}'),
(309, 34, '_wp_old_date', '2023-06-06'),
(310, 35, '_wp_old_date', '2023-06-06'),
(311, 36, '_wp_old_date', '2023-06-06'),
(312, 37, '_wp_old_date', '2023-06-06'),
(313, 38, '_wp_old_date', '2023-06-06'),
(314, 39, '_wp_old_date', '2023-06-06'),
(315, 40, '_wp_old_date', '2023-06-06'),
(316, 41, '_wp_old_date', '2023-06-06'),
(317, 42, '_wp_old_date', '2023-06-06'),
(318, 43, '_wp_old_date', '2023-06-06'),
(319, 1, '_edit_lock', '1686653351:1'),
(320, 53, '_edit_lock', '1686408937:1'),
(321, 53, '_wp_page_template', 'template-homepage.php'),
(322, 53, '_edit_last', '1'),
(333, 60, '_wp_attached_file', '2023/06/property-1-1.jpg'),
(334, 60, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:304;s:6:"height";i:248;s:4:"file";s:24:"2023/06/property-1-1.jpg";s:8:"filesize";i:23011;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:24:"property-1-1-300x245.jpg";s:5:"width";i:300;s:6:"height";i:245;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21979;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"property-1-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:12542;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:8:"N O_O ne";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1453321584";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(335, 61, '_wp_attached_file', '2023/06/property-2.jpg'),
(336, 61, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:304;s:6:"height";i:248;s:4:"file";s:22:"2023/06/property-2.jpg";s:8:"filesize";i:38791;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:22:"property-2-300x245.jpg";s:5:"width";i:300;s:6:"height";i:245;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18655;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"property-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6494;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(337, 62, '_wp_attached_file', '2023/06/property-3.jpg'),
(338, 62, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:304;s:6:"height";i:248;s:4:"file";s:22:"2023/06/property-3.jpg";s:8:"filesize";i:32203;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:22:"property-3-300x245.jpg";s:5:"width";i:300;s:6:"height";i:245;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14690;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"property-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5392;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(339, 55, 'status', 'sell'),
(340, 55, '_status', 'field_6488417e1fc4e'),
(341, 55, 'waterfront', 'Yes'),
(342, 55, '_waterfront', 'field_6488422d1fc50'),
(343, 55, 'built_in', '2003'),
(344, 55, '_built_in', 'field_6488423d1fc51'),
(345, 55, 'parking', '2 Or More Spaces,Covered Parking,Valet Parking'),
(346, 55, '_parking', 'field_648842491fc52'),
(347, 55, 'view', 'Intracoastal View,Direct ew'),
(348, 55, '_view', 'field_648842551fc53'),
(349, 55, 'image1', ''),
(350, 55, '_image1', 'field_6488432815fe8'),
(351, 55, 'image2', '60'),
(352, 55, '_image2', 'field_648843fa0c84b'),
(353, 55, 'image', '62'),
(354, 55, '_image', 'field_6488432815fe8') ;
INSERT INTO `re_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(355, 72, '_edit_last', '1'),
(356, 72, '_edit_lock', '1686843163:1'),
(357, 72, '_thumbnail_id', '60'),
(358, 72, 'price', '22200'),
(359, 72, '_price', 'field_64847c2feb7fc'),
(360, 72, 'area', '219'),
(361, 72, '_area', 'field_64847c59eb7fd'),
(362, 72, 'bed_room', '1'),
(363, 72, '_bed_room', 'field_64847f562ea19'),
(364, 72, 'bath_room', '3'),
(365, 72, '_bath_room', 'field_64847f2f2ea18'),
(366, 72, 'garage', '4'),
(367, 72, '_garage', 'field_64847f852ea1a'),
(368, 72, 'status', 'sell'),
(369, 72, '_status', 'field_6488417e1fc4e'),
(370, 72, 'waterfront', 'yes'),
(371, 72, '_waterfront', 'field_6488422d1fc50'),
(372, 72, 'built_in', '2002'),
(373, 72, '_built_in', 'field_6488423d1fc51'),
(374, 72, 'parking', 'yes'),
(375, 72, '_parking', 'field_648842491fc52'),
(376, 72, 'view', 'forest'),
(377, 72, '_view', 'field_648842551fc53'),
(378, 72, 'image1', '62'),
(379, 72, '_image1', 'field_6488432815fe8'),
(380, 72, 'image2', '118'),
(381, 72, '_image2', 'field_648843fa0c84b'),
(382, 73, '_wp_attached_file', '2023/06/property1.jpg'),
(383, 73, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:21:"2023/06/property1.jpg";s:8:"filesize";i:80661;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:21:"property1-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10162;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"property1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4718;}s:12:"medium_large";a:5:{s:4:"file";s:21:"property1-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:44505;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(384, 74, '_wp_attached_file', '2023/06/property3.jpg'),
(385, 74, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:21:"2023/06/property3.jpg";s:8:"filesize";i:166932;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:21:"property3-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:28000;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"property3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21120;}s:12:"medium_large";a:5:{s:4:"file";s:21:"property3-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:74693;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"8";s:6:"credit";s:11:"Huw Lambert";s:6:"camera";s:21:"Canon EOS 5D Mark III";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1359145856";s:9:"copyright";s:18:"Huw@HuwLambert.com";s:12:"focal_length";s:2:"17";s:3:"iso";s:4:"1000";s:13:"shutter_speed";s:3:"0.6";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(386, 76, '_wp_attached_file', '2023/06/property2.jpg'),
(387, 76, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:21:"2023/06/property2.jpg";s:8:"filesize";i:240574;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:21:"property2-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:22003;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"property2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13229;}s:12:"medium_large";a:5:{s:4:"file";s:21:"property2-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:94930;}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"3.5";s:6:"credit";s:0:"";s:6:"camera";s:19:"Canon EOS REBEL T2i";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1325755613";s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"18";s:3:"iso";s:3:"100";s:13:"shutter_speed";s:8:"0.000625";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(388, 55, 'image3', '62'),
(389, 55, '_image3', 'field_64887ae127b6e'),
(390, 77, '_wp_attached_file', '2023/06/countdown_-_2637-540p.mp4'),
(391, 77, '_wp_attachment_metadata', 'a:10:{s:7:"bitrate";i:1501248;s:8:"filesize";i:1435565;s:9:"mime_type";s:15:"video/quicktime";s:6:"length";i:8;s:16:"length_formatted";s:4:"0:08";s:5:"width";i:960;s:6:"height";i:540;s:10:"fileformat";s:3:"mp4";s:10:"dataformat";s:9:"quicktime";s:17:"created_timestamp";i:1459757856;}'),
(392, 78, '_edit_last', '1'),
(393, 78, '_edit_lock', '1686842949:1'),
(394, 79, '_wp_attached_file', '2023/06/small-property-3.jpg'),
(395, 79, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:70;s:6:"height";i:70;s:4:"file";s:28:"2023/06/small-property-3.jpg";s:8:"filesize";i:4462;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(396, 78, '_thumbnail_id', '79'),
(397, 78, 'price', '30000'),
(398, 78, '_price', 'field_64847c2feb7fc'),
(399, 78, 'area', '312'),
(400, 78, '_area', 'field_64847c59eb7fd'),
(401, 78, 'bed_room', '1'),
(402, 78, '_bed_room', 'field_64847f562ea19'),
(403, 78, 'bath_room', '1'),
(404, 78, '_bath_room', 'field_64847f2f2ea18'),
(405, 78, 'garage', '0'),
(406, 78, '_garage', 'field_64847f852ea1a'),
(407, 78, 'status', 'sell'),
(408, 78, '_status', 'field_6488417e1fc4e'),
(409, 78, 'waterfront', ''),
(410, 78, '_waterfront', 'field_6488422d1fc50'),
(411, 78, 'built_in', ''),
(412, 78, '_built_in', 'field_6488423d1fc51'),
(413, 78, 'parking', ''),
(414, 78, '_parking', 'field_648842491fc52'),
(415, 78, 'view', ''),
(416, 78, '_view', 'field_648842551fc53'),
(417, 78, 'image1', '119'),
(418, 78, '_image1', 'field_6488432815fe8'),
(419, 78, 'image2', ''),
(420, 78, '_image2', 'field_648843fa0c84b'),
(421, 78, 'image3', ''),
(422, 78, '_image3', 'field_64887ae127b6e'),
(423, 72, 'image3', '120'),
(424, 72, '_image3', 'field_64887ae127b6e'),
(425, 82, '_edit_lock', '1686819055:1'),
(426, 83, '_edit_lock', '1686819595:1'),
(427, 84, 'user_registration_form_setting_login_options', '0'),
(428, 84, 'user_registration_form_setting_enable_strong_password', 'no'),
(429, 84, 'user_registration_form_setting_default_user_role', 'subscriber'),
(430, 85, '_edit_lock', '1686821102:1'),
(431, 86, '_wp_trash_meta_status', 'publish'),
(432, 86, '_wp_trash_meta_time', '1686821187'),
(433, 86, '_wp_desired_post_slug', 'my-account'),
(434, 85, '_wp_trash_meta_status', 'publish'),
(435, 85, '_wp_trash_meta_time', '1686821187'),
(436, 85, '_wp_desired_post_slug', 'registration'),
(437, 89, '_edit_lock', '1686821256:1'),
(438, 90, '_edit_lock', '1686821632:1'),
(439, 90, '_wp_page_template', 'template-newproperty.php'),
(440, 90, '_edit_last', '1'),
(441, 93, 'area', '241'),
(442, 92, '_edit_lock', '1686822599:1'),
(443, 94, 'area', '234'),
(444, 94, '_edit_lock', '1686826615:1'),
(445, 95, 'status', 'sell'),
(446, 95, 'price', '45000'),
(447, 95, 'area', '212'),
(448, 95, 'bed_room', '1'),
(449, 95, 'bath_room', '1'),
(450, 95, 'garage', '1'),
(451, 95, 'waterfront', 'yes'),
(452, 95, 'built_in', '2012'),
(453, 95, 'parking', 'yes'),
(454, 95, 'view', 'forest') ;
INSERT INTO `re_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(455, 95, '_edit_lock', '1686827559:1'),
(456, 96, 'status', 'sell'),
(457, 96, 'price', '10000'),
(458, 96, 'area', '312'),
(459, 96, 'bed_room', '1'),
(460, 96, 'bath_room', '1'),
(461, 96, 'garage', '1'),
(462, 96, 'waterfront', 'yes'),
(463, 96, 'built_in', '2021'),
(464, 96, 'parking', 'yes'),
(465, 96, 'view', 'forest'),
(466, 96, '_edit_lock', '1686827746:1'),
(467, 97, 'status', 'sell'),
(468, 97, 'price', '323232'),
(469, 97, 'area', '321'),
(470, 97, 'bed_room', '1'),
(471, 97, 'bath_room', '1'),
(472, 97, 'garage', '1'),
(473, 97, 'waterfront', '1'),
(474, 97, 'built_in', '1'),
(475, 97, 'parking', '1'),
(476, 97, 'view', '1'),
(477, 97, '_edit_lock', '1686827828:1'),
(478, 98, 'status', ''),
(479, 98, 'price', ''),
(480, 98, 'area', ''),
(481, 98, 'bed_room', ''),
(482, 98, 'bath_room', ''),
(483, 98, 'garage', ''),
(484, 98, 'waterfront', ''),
(485, 98, 'built_in', ''),
(486, 98, 'parking', ''),
(487, 98, 'view', ''),
(488, 98, '_edit_lock', '1686828139:1'),
(489, 99, 'status', ''),
(490, 99, 'price', ''),
(491, 99, 'area', ''),
(492, 99, 'bed_room', ''),
(493, 99, 'bath_room', ''),
(494, 99, 'garage', ''),
(495, 99, 'waterfront', ''),
(496, 99, 'built_in', ''),
(497, 99, 'parking', ''),
(498, 99, 'view', ''),
(499, 100, '_wp_attached_file', '2023/06/property-5.jpg'),
(500, 100, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:304;s:6:"height";i:248;s:4:"file";s:22:"2023/06/property-5.jpg";s:8:"filesize";i:23291;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:22:"property-5-300x245.jpg";s:5:"width";i:300;s:6:"height";i:245;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11513;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"property-5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5268;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(501, 99, '_thumbnail_id', '100'),
(502, 99, '_edit_lock', '1686828164:1'),
(503, 99, '_wp_trash_meta_status', 'publish'),
(504, 99, '_wp_trash_meta_time', '1686828323'),
(505, 99, '_wp_desired_post_slug', '%d0%b0%d1%8b%d0%b2%d0%b0%d0%b2%d1%8b%d0%b0%d1%8b%d0%b2'),
(506, 98, '_wp_trash_meta_status', 'publish'),
(507, 98, '_wp_trash_meta_time', '1686828323'),
(508, 98, '_wp_desired_post_slug', 'qw12'),
(509, 97, '_wp_trash_meta_status', 'publish'),
(510, 97, '_wp_trash_meta_time', '1686828324'),
(511, 97, '_wp_desired_post_slug', 'qwerty1234'),
(512, 96, '_wp_trash_meta_status', 'publish'),
(513, 96, '_wp_trash_meta_time', '1686828324'),
(514, 96, '_wp_desired_post_slug', 'villa'),
(515, 95, '_wp_trash_meta_status', 'publish'),
(516, 95, '_wp_trash_meta_time', '1686828324'),
(517, 95, '_wp_desired_post_slug', 'six'),
(518, 94, '_wp_trash_meta_status', 'publish'),
(519, 94, '_wp_trash_meta_time', '1686828325'),
(520, 94, '_wp_desired_post_slug', 'five'),
(521, 93, '_wp_trash_meta_status', 'publish'),
(522, 93, '_wp_trash_meta_time', '1686828325'),
(523, 93, '_wp_desired_post_slug', '%d0%b9%d1%86%d0%b9%d1%83%d1%86'),
(524, 92, '_wp_trash_meta_status', 'publish'),
(525, 92, '_wp_trash_meta_time', '1686828325'),
(526, 92, '_wp_desired_post_slug', '%d1%87%d0%b5%d1%82%d0%b2%d0%b5%d1%80%d1%82%d1%8b%d0%b9'),
(527, 101, 'status', 'sell'),
(528, 101, 'price', ''),
(529, 101, 'area', ''),
(530, 101, 'bed_room', ''),
(531, 101, 'bath_room', ''),
(532, 101, 'garage', ''),
(533, 101, 'waterfront', ''),
(534, 101, 'built_in', ''),
(535, 101, 'parking', ''),
(536, 101, 'view', ''),
(537, 102, '_wp_attached_file', '2023/06/property-4.jpg'),
(538, 102, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:440;s:6:"height";i:330;s:4:"file";s:22:"2023/06/property-4.jpg";s:8:"filesize";i:46181;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:22:"property-4-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:23336;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"property-4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9635;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(539, 101, 'image1', '102'),
(540, 101, '_edit_lock', '1686829709:1'),
(541, 101, '_edit_last', '1'),
(542, 101, '_price', 'field_64847c2feb7fc'),
(543, 101, '_area', 'field_64847c59eb7fd'),
(544, 101, '_bed_room', 'field_64847f562ea19'),
(545, 101, '_bath_room', 'field_64847f2f2ea18'),
(546, 101, '_garage', 'field_64847f852ea1a'),
(547, 101, '_status', 'field_6488417e1fc4e'),
(548, 101, '_waterfront', 'field_6488422d1fc50'),
(549, 101, '_built_in', 'field_6488423d1fc51'),
(550, 101, '_parking', 'field_648842491fc52'),
(551, 101, '_view', 'field_648842551fc53'),
(552, 101, '_image1', 'field_6488432815fe8'),
(553, 101, 'image2', ''),
(554, 101, '_image2', 'field_648843fa0c84b') ;
INSERT INTO `re_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(555, 101, 'image3', ''),
(556, 101, '_image3', 'field_64887ae127b6e'),
(557, 103, 'status', 'sell'),
(558, 103, 'price', ''),
(559, 103, 'area', ''),
(560, 103, 'bed_room', ''),
(561, 103, 'bath_room', ''),
(562, 103, 'garage', ''),
(563, 103, 'waterfront', ''),
(564, 103, 'built_in', ''),
(565, 103, 'parking', ''),
(566, 103, 'view', ''),
(567, 104, '_wp_attached_file', '2023/06/property4.jpg'),
(568, 104, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:21:"2023/06/property4.jpg";s:8:"filesize";i:176890;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:21:"property4-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:15192;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"property4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6793;}s:12:"medium_large";a:5:{s:4:"file";s:21:"property4-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:76062;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(569, 103, 'image1', '104'),
(570, 103, '_edit_lock', '1686841743:1'),
(571, 103, '_edit_last', '1'),
(572, 103, '_price', 'field_64847c2feb7fc'),
(573, 103, '_area', 'field_64847c59eb7fd'),
(574, 103, '_bed_room', 'field_64847f562ea19'),
(575, 103, '_bath_room', 'field_64847f2f2ea18'),
(576, 103, '_garage', 'field_64847f852ea1a'),
(577, 103, '_status', 'field_6488417e1fc4e'),
(578, 103, '_waterfront', 'field_6488422d1fc50'),
(579, 103, '_built_in', 'field_6488423d1fc51'),
(580, 103, '_parking', 'field_648842491fc52'),
(581, 103, '_view', 'field_648842551fc53'),
(582, 103, '_image1', 'field_6488432815fe8'),
(583, 103, 'image2', ''),
(584, 103, '_image2', 'field_648843fa0c84b'),
(585, 103, 'image3', ''),
(586, 103, '_image3', 'field_64887ae127b6e'),
(587, 107, 'status', 'sell'),
(588, 107, 'price', ''),
(589, 107, 'area', ''),
(590, 107, 'bed_room', ''),
(591, 107, 'bath_room', ''),
(592, 107, 'garage', ''),
(593, 107, 'waterfront', ''),
(594, 107, 'built_in', ''),
(595, 107, 'parking', ''),
(596, 107, 'view', ''),
(602, 107, 'image1', '109'),
(603, 107, '_edit_lock', '1686829005:3'),
(604, 107, '_edit_last', '3'),
(605, 107, '_price', 'field_64847c2feb7fc'),
(606, 107, '_area', 'field_64847c59eb7fd'),
(607, 107, '_bed_room', 'field_64847f562ea19'),
(608, 107, '_bath_room', 'field_64847f2f2ea18'),
(609, 107, '_garage', 'field_64847f852ea1a'),
(610, 107, '_status', 'field_6488417e1fc4e'),
(611, 107, '_waterfront', 'field_6488422d1fc50'),
(612, 107, '_built_in', 'field_6488423d1fc51'),
(613, 107, '_parking', 'field_648842491fc52'),
(614, 107, '_view', 'field_648842551fc53'),
(615, 107, '_image1', 'field_6488432815fe8'),
(616, 107, 'image2', ''),
(617, 107, '_image2', 'field_648843fa0c84b'),
(618, 107, 'image3', ''),
(619, 107, '_image3', 'field_64887ae127b6e'),
(620, 110, 'status', ''),
(621, 110, 'price', ''),
(622, 110, 'area', ''),
(623, 110, 'bed_room', ''),
(624, 110, 'bath_room', ''),
(625, 110, 'garage', ''),
(626, 110, 'waterfront', ''),
(627, 110, 'built_in', ''),
(628, 110, 'parking', ''),
(629, 110, 'view', ''),
(630, 111, '_wp_attached_file', '2023/06/property1-2.jpg'),
(631, 111, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:23:"2023/06/property1-2.jpg";s:8:"filesize";i:80661;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:23:"property1-2-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10162;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"property1-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4718;}s:12:"medium_large";a:5:{s:4:"file";s:23:"property1-2-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:44505;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(632, 110, '_thumbnail_id', '111'),
(633, 112, '_wp_attached_file', '2023/06/property3-1.jpg'),
(634, 112, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:23:"2023/06/property3-1.jpg";s:8:"filesize";i:166932;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:23:"property3-1-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:28000;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"property3-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21120;}s:12:"medium_large";a:5:{s:4:"file";s:23:"property3-1-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:74693;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"8";s:6:"credit";s:11:"Huw Lambert";s:6:"camera";s:21:"Canon EOS 5D Mark III";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1359145856";s:9:"copyright";s:18:"Huw@HuwLambert.com";s:12:"focal_length";s:2:"17";s:3:"iso";s:4:"1000";s:13:"shutter_speed";s:3:"0.6";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(635, 110, 'image1', '112'),
(636, 113, 'status', ''),
(637, 113, 'price', ''),
(638, 113, 'area', ''),
(639, 113, 'bed_room', ''),
(640, 113, 'bath_room', ''),
(641, 113, 'garage', ''),
(642, 113, 'waterfront', ''),
(643, 113, 'built_in', ''),
(644, 113, 'parking', ''),
(645, 113, 'view', ''),
(646, 114, '_wp_attached_file', '2023/06/property2-2.jpg'),
(647, 114, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:23:"2023/06/property2-2.jpg";s:8:"filesize";i:240574;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:23:"property2-2-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:22003;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"property2-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13229;}s:12:"medium_large";a:5:{s:4:"file";s:23:"property2-2-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:94930;}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"3.5";s:6:"credit";s:0:"";s:6:"camera";s:19:"Canon EOS REBEL T2i";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1325755613";s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"18";s:3:"iso";s:3:"100";s:13:"shutter_speed";s:8:"0.000625";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(648, 113, 'image1', '114'),
(649, 115, '_wp_attached_file', '2023/06/property4-1.jpg'),
(650, 115, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:23:"2023/06/property4-1.jpg";s:8:"filesize";i:176890;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:23:"property4-1-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:15192;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"property4-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6793;}s:12:"medium_large";a:5:{s:4:"file";s:23:"property4-1-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:76062;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(651, 113, 'image2', '115'),
(652, 116, '_wp_attached_file', '2023/06/property1-3.jpg'),
(653, 116, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:23:"2023/06/property1-3.jpg";s:8:"filesize";i:80661;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:23:"property1-3-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10162;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"property1-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4718;}s:12:"medium_large";a:5:{s:4:"file";s:23:"property1-3-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:44505;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(654, 113, 'image3', '116'),
(655, 113, '_edit_lock', '1686837458:1'),
(656, 117, 'status', ''),
(657, 117, 'price', ''),
(658, 117, 'area', ''),
(659, 117, 'bed_room', '') ;
INSERT INTO `re_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(660, 117, 'bath_room', ''),
(661, 117, 'garage', ''),
(662, 117, 'waterfront', ''),
(663, 117, 'built_in', ''),
(664, 117, 'parking', ''),
(665, 117, 'view', ''),
(666, 118, '_wp_attached_file', '2023/06/property2-3.jpg'),
(667, 118, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:23:"2023/06/property2-3.jpg";s:8:"filesize";i:240574;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:23:"property2-3-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:22003;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"property2-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13229;}s:12:"medium_large";a:5:{s:4:"file";s:23:"property2-3-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:94930;}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"3.5";s:6:"credit";s:0:"";s:6:"camera";s:19:"Canon EOS REBEL T2i";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1325755613";s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"18";s:3:"iso";s:3:"100";s:13:"shutter_speed";s:8:"0.000625";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(668, 117, 'image1', '118'),
(669, 119, '_wp_attached_file', '2023/06/property3-2.jpg'),
(670, 119, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:23:"2023/06/property3-2.jpg";s:8:"filesize";i:166932;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:23:"property3-2-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:28000;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"property3-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21120;}s:12:"medium_large";a:5:{s:4:"file";s:23:"property3-2-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:74693;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"8";s:6:"credit";s:11:"Huw Lambert";s:6:"camera";s:21:"Canon EOS 5D Mark III";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1359145856";s:9:"copyright";s:18:"Huw@HuwLambert.com";s:12:"focal_length";s:2:"17";s:3:"iso";s:4:"1000";s:13:"shutter_speed";s:3:"0.6";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(671, 117, 'image2', '119'),
(672, 120, '_wp_attached_file', '2023/06/property4-2.jpg'),
(673, 120, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:23:"2023/06/property4-2.jpg";s:8:"filesize";i:176890;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:23:"property4-2-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:15192;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"property4-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6793;}s:12:"medium_large";a:5:{s:4:"file";s:23:"property4-2-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:76062;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(674, 117, 'image3', '120'),
(675, 117, '_wp_trash_meta_status', 'publish'),
(676, 117, '_wp_trash_meta_time', '1686843016'),
(677, 117, '_wp_desired_post_slug', '54554'),
(678, 113, '_wp_trash_meta_status', 'publish'),
(679, 113, '_wp_trash_meta_time', '1686843016'),
(680, 113, '_wp_desired_post_slug', '%d0%b9%d1%86%d0%b9%d1%86%d0%b9'),
(681, 110, '_wp_trash_meta_status', 'publish'),
(682, 110, '_wp_trash_meta_time', '1686843016'),
(683, 110, '_wp_desired_post_slug', '%d0%be%d1%88%d0%b2%d1%84%d1%8b%d0%be%d1%88'),
(684, 107, '_wp_trash_meta_status', 'publish'),
(685, 107, '_wp_trash_meta_time', '1686843017'),
(686, 107, '_wp_desired_post_slug', 'villa-123'),
(687, 103, '_wp_trash_meta_status', 'publish'),
(688, 103, '_wp_trash_meta_time', '1686843017'),
(689, 103, '_wp_desired_post_slug', 'idk'),
(690, 101, '_wp_trash_meta_status', 'publish'),
(691, 101, '_wp_trash_meta_time', '1686843017'),
(692, 101, '_wp_desired_post_slug', 'villa-the-best'),
(693, 24, 'status', 'sell'),
(694, 24, '_status', 'field_6488417e1fc4e'),
(695, 24, 'waterfront', ''),
(696, 24, '_waterfront', 'field_6488422d1fc50'),
(697, 24, 'built_in', ''),
(698, 24, '_built_in', 'field_6488423d1fc51'),
(699, 24, 'parking', ''),
(700, 24, '_parking', 'field_648842491fc52'),
(701, 24, 'view', ''),
(702, 24, '_view', 'field_648842551fc53'),
(703, 24, 'image1', '25'),
(704, 24, '_image1', 'field_6488432815fe8'),
(705, 24, 'image2', ''),
(706, 24, '_image2', 'field_648843fa0c84b'),
(707, 24, 'image3', ''),
(708, 24, '_image3', 'field_64887ae127b6e'),
(709, 121, '_wp_attached_file', '2023/06/property3-3.jpg'),
(710, 121, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:23:"2023/06/property3-3.jpg";s:8:"filesize";i:166932;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:23:"property3-3-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:28000;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"property3-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21120;}s:12:"medium_large";a:5:{s:4:"file";s:23:"property3-3-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:74693;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"8";s:6:"credit";s:11:"Huw Lambert";s:6:"camera";s:21:"Canon EOS 5D Mark III";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1359145856";s:9:"copyright";s:18:"Huw@HuwLambert.com";s:12:"focal_length";s:2:"17";s:3:"iso";s:4:"1000";s:13:"shutter_speed";s:3:"0.6";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(711, 122, '_wp_attached_file', '2023/06/property4-3.jpg'),
(712, 122, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:23:"2023/06/property4-3.jpg";s:8:"filesize";i:176890;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:23:"property4-3-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:15192;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"property4-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6793;}s:12:"medium_large";a:5:{s:4:"file";s:23:"property4-3-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:76062;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(713, 123, 'status', ''),
(714, 123, 'price', ''),
(715, 123, 'area', ''),
(716, 123, 'bed_room', ''),
(717, 123, 'bath_room', ''),
(718, 123, 'garage', ''),
(719, 123, 'waterfront', ''),
(720, 123, 'built_in', ''),
(721, 123, 'parking', ''),
(722, 123, 'view', ''),
(723, 124, '_wp_attached_file', '2023/06/property1-4.jpg'),
(724, 124, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:23:"2023/06/property1-4.jpg";s:8:"filesize";i:80661;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:23:"property1-4-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10162;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"property1-4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4718;}s:12:"medium_large";a:5:{s:4:"file";s:23:"property1-4-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:44505;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(725, 123, 'image1', '124'),
(726, 125, '_wp_attached_file', '2023/06/property2-4.jpg'),
(727, 125, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:23:"2023/06/property2-4.jpg";s:8:"filesize";i:240574;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:23:"property2-4-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:22003;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"property2-4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13229;}s:12:"medium_large";a:5:{s:4:"file";s:23:"property2-4-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:94930;}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"3.5";s:6:"credit";s:0:"";s:6:"camera";s:19:"Canon EOS REBEL T2i";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1325755613";s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"18";s:3:"iso";s:3:"100";s:13:"shutter_speed";s:8:"0.000625";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(728, 123, 'image2', '125'),
(729, 126, '_wp_attached_file', '2023/06/property3-4.jpg'),
(730, 126, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:23:"2023/06/property3-4.jpg";s:8:"filesize";i:166932;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:23:"property3-4-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:28000;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"property3-4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21120;}s:12:"medium_large";a:5:{s:4:"file";s:23:"property3-4-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:74693;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"8";s:6:"credit";s:11:"Huw Lambert";s:6:"camera";s:21:"Canon EOS 5D Mark III";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1359145856";s:9:"copyright";s:18:"Huw@HuwLambert.com";s:12:"focal_length";s:2:"17";s:3:"iso";s:4:"1000";s:13:"shutter_speed";s:3:"0.6";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(731, 123, 'image3', '126'),
(732, 127, 'status', ''),
(733, 127, 'price', ''),
(734, 127, 'area', ''),
(735, 127, 'bed_room', ''),
(736, 127, 'bath_room', ''),
(737, 127, 'garage', ''),
(738, 127, 'waterfront', ''),
(739, 127, 'built_in', ''),
(740, 127, 'parking', ''),
(741, 127, 'view', ''),
(742, 128, '_wp_attached_file', '2023/06/pngegg.png'),
(743, 128, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:256;s:6:"height";i:256;s:4:"file";s:18:"2023/06/pngegg.png";s:8:"filesize";i:89024;s:5:"sizes";a:1:{s:9:"thumbnail";a:5:{s:4:"file";s:18:"pngegg-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:28862;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(744, 127, 'image1', '128'),
(745, 129, '_wp_attached_file', '2023/06/pngegg-1.png'),
(746, 129, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:256;s:6:"height";i:256;s:4:"file";s:20:"2023/06/pngegg-1.png";s:8:"filesize";i:52548;s:5:"sizes";a:1:{s:9:"thumbnail";a:5:{s:4:"file";s:20:"pngegg-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:17830;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(747, 127, 'image2', '129'),
(748, 130, 'status', 'sell'),
(749, 130, 'price', '313131'),
(750, 130, 'area', '231'),
(751, 130, 'bed_room', '1'),
(752, 130, 'bath_room', '2'),
(753, 130, 'garage', '3'),
(754, 130, 'waterfront', 'no'),
(755, 130, 'built_in', '2121'),
(756, 130, 'parking', 'no'),
(757, 130, 'view', 'qwerty1'),
(758, 131, '_wp_attached_file', '2023/06/property-1-2.jpg'),
(759, 131, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:304;s:6:"height";i:248;s:4:"file";s:24:"2023/06/property-1-2.jpg";s:8:"filesize";i:23011;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:24:"property-1-2-300x245.jpg";s:5:"width";i:300;s:6:"height";i:245;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21979;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"property-1-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:12542;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:8:"N O_O ne";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1453321584";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ;
INSERT INTO `re_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(760, 130, '_thumbnail_id', '131'),
(761, 132, '_wp_attached_file', '2023/06/property1-5.jpg'),
(762, 132, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:23:"2023/06/property1-5.jpg";s:8:"filesize";i:80661;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:23:"property1-5-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10162;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"property1-5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4718;}s:12:"medium_large";a:5:{s:4:"file";s:23:"property1-5-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:44505;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(763, 130, 'image1', '132'),
(764, 133, '_wp_attached_file', '2023/06/property2-5.jpg'),
(765, 133, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:23:"2023/06/property2-5.jpg";s:8:"filesize";i:240574;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:23:"property2-5-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:22003;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"property2-5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13229;}s:12:"medium_large";a:5:{s:4:"file";s:23:"property2-5-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:94930;}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"3.5";s:6:"credit";s:0:"";s:6:"camera";s:19:"Canon EOS REBEL T2i";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1325755613";s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"18";s:3:"iso";s:3:"100";s:13:"shutter_speed";s:8:"0.000625";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(766, 130, 'image2', '133'),
(767, 134, '_wp_attached_file', '2023/06/property3-5.jpg'),
(768, 134, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:850;s:6:"height";i:570;s:4:"file";s:23:"2023/06/property3-5.jpg";s:8:"filesize";i:166932;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:23:"property3-5-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:28000;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"property3-5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21120;}s:12:"medium_large";a:5:{s:4:"file";s:23:"property3-5-768x515.jpg";s:5:"width";i:768;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:74693;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"8";s:6:"credit";s:11:"Huw Lambert";s:6:"camera";s:21:"Canon EOS 5D Mark III";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1359145856";s:9:"copyright";s:18:"Huw@HuwLambert.com";s:12:"focal_length";s:2:"17";s:3:"iso";s:4:"1000";s:13:"shutter_speed";s:3:"0.6";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(769, 130, 'image3', '134'),
(770, 130, '_edit_lock', '1686846157:1'),
(771, 135, 'status', ''),
(772, 135, 'price', ''),
(773, 135, 'area', ''),
(774, 135, 'bed_room', ''),
(775, 135, 'bath_room', ''),
(776, 135, 'garage', ''),
(777, 135, 'waterfront', ''),
(778, 135, 'built_in', ''),
(779, 135, 'parking', ''),
(780, 135, 'view', ''),
(781, 135, '_edit_lock', '1686846487:1'),
(782, 136, 'status', ''),
(783, 136, 'price', ''),
(784, 136, 'area', ''),
(785, 136, 'bed_room', ''),
(786, 136, 'bath_room', ''),
(787, 136, 'garage', ''),
(788, 136, 'waterfront', ''),
(789, 136, 'built_in', ''),
(790, 136, 'parking', ''),
(791, 136, 'view', ''),
(792, 136, '_edit_lock', '1686846669:1'),
(793, 137, 'status', ''),
(794, 137, 'price', ''),
(795, 137, 'area', ''),
(796, 137, 'bed_room', ''),
(797, 137, 'bath_room', ''),
(798, 137, 'garage', ''),
(799, 137, 'waterfront', ''),
(800, 137, 'built_in', ''),
(801, 137, 'parking', ''),
(802, 137, 'view', ''),
(803, 137, '_edit_lock', '1686847969:1'),
(804, 138, 'status', ''),
(805, 138, 'price', ''),
(806, 138, 'area', ''),
(807, 138, 'bed_room', ''),
(808, 138, 'bath_room', ''),
(809, 138, 'garage', ''),
(810, 138, 'waterfront', ''),
(811, 138, 'built_in', ''),
(812, 138, 'parking', ''),
(813, 138, 'view', ''),
(814, 138, '_edit_lock', '1686847833:1'),
(815, 138, '_wp_trash_meta_status', 'publish'),
(816, 138, '_wp_trash_meta_time', '1686849988'),
(817, 138, '_wp_desired_post_slug', '545454'),
(818, 137, '_wp_trash_meta_status', 'publish'),
(819, 137, '_wp_trash_meta_time', '1686849989'),
(820, 137, '_wp_desired_post_slug', '21214243'),
(821, 136, '_wp_trash_meta_status', 'publish'),
(822, 136, '_wp_trash_meta_time', '1686849989'),
(823, 136, '_wp_desired_post_slug', '3232'),
(824, 135, '_wp_trash_meta_status', 'publish'),
(825, 135, '_wp_trash_meta_time', '1686849989'),
(826, 135, '_wp_desired_post_slug', '12121'),
(827, 130, '_wp_trash_meta_status', 'publish'),
(828, 130, '_wp_trash_meta_time', '1686849990'),
(829, 130, '_wp_desired_post_slug', 'qwerty'),
(830, 127, '_wp_trash_meta_status', 'publish'),
(831, 127, '_wp_trash_meta_time', '1686849990'),
(832, 127, '_wp_desired_post_slug', '%d0%bf%d0%b2%d0%b0%d0%bf'),
(833, 123, '_wp_trash_meta_status', 'publish'),
(834, 123, '_wp_trash_meta_time', '1686849990'),
(835, 123, '_wp_desired_post_slug', '5431'),
(836, 81, '_wp_trash_meta_status', 'auto-draft'),
(837, 81, '_wp_trash_meta_time', '1686850565'),
(838, 81, '_wp_desired_post_slug', ''),
(839, 106, '_wp_trash_meta_status', 'auto-draft'),
(840, 106, '_wp_trash_meta_time', '1686850567'),
(841, 106, '_wp_desired_post_slug', ''),
(842, 142, 'status', ''),
(843, 142, 'price', ''),
(844, 142, 'area', ''),
(845, 142, 'bed_room', ''),
(846, 142, 'bath_room', ''),
(847, 142, 'garage', ''),
(848, 142, 'waterfront', ''),
(849, 142, 'built_in', ''),
(850, 142, 'parking', ''),
(851, 142, 'view', ''),
(852, 143, 'status', 'sell'),
(853, 143, 'price', '23'),
(854, 143, 'area', '555'),
(855, 143, 'bed_room', '55'),
(856, 143, 'bath_room', '55'),
(857, 143, 'garage', ''),
(858, 143, 'waterfront', ''),
(859, 143, 'built_in', '') ;
INSERT INTO `re_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(860, 143, 'parking', ''),
(861, 143, 'view', ''),
(862, 144, 'status', 'sell'),
(863, 144, 'price', '12312312312'),
(864, 144, 'area', '13123123'),
(865, 144, 'bed_room', '12321312'),
(866, 144, 'bath_room', '312312'),
(867, 144, 'garage', ''),
(868, 144, 'waterfront', ''),
(869, 144, 'built_in', ''),
(870, 144, 'parking', ''),
(871, 144, 'view', ''),
(872, 145, 'status', 'sell'),
(873, 145, 'price', '12312312'),
(874, 145, 'area', '123123'),
(875, 145, 'bed_room', '12312'),
(876, 145, 'bath_room', '12312'),
(877, 145, 'garage', ''),
(878, 145, 'waterfront', ''),
(879, 145, 'built_in', ''),
(880, 145, 'parking', ''),
(881, 145, 'view', ''),
(882, 146, 'status', 'sell'),
(883, 146, 'price', '123123'),
(884, 146, 'area', '123'),
(885, 146, 'bed_room', '12'),
(886, 146, 'bath_room', '12'),
(887, 146, 'garage', ''),
(888, 146, 'waterfront', ''),
(889, 146, 'built_in', ''),
(890, 146, 'parking', ''),
(891, 146, 'view', ''),
(892, 146, '_wp_trash_meta_status', 'publish'),
(893, 146, '_wp_trash_meta_time', '1686855056'),
(894, 146, '_wp_desired_post_slug', '1232131'),
(895, 145, '_wp_trash_meta_status', 'publish'),
(896, 145, '_wp_trash_meta_time', '1686855056'),
(897, 145, '_wp_desired_post_slug', '12321312'),
(898, 144, '_wp_trash_meta_status', 'publish'),
(899, 144, '_wp_trash_meta_time', '1686855057'),
(900, 144, '_wp_desired_post_slug', '231321'),
(901, 143, '_wp_trash_meta_status', 'publish'),
(902, 143, '_wp_trash_meta_time', '1686855057'),
(903, 143, '_wp_desired_post_slug', 'qweqweqw'),
(904, 142, '_wp_trash_meta_status', 'publish'),
(905, 142, '_wp_trash_meta_time', '1686855057'),
(906, 142, '_wp_desired_post_slug', 'qwerty'),
(907, 78, '_wp_trash_meta_status', 'publish'),
(908, 78, '_wp_trash_meta_time', '1686855058'),
(909, 78, '_wp_desired_post_slug', '%d1%82%d1%80%d0%b5%d1%82%d0%b8%d0%b9'),
(910, 72, '_wp_trash_meta_status', 'publish'),
(911, 72, '_wp_trash_meta_time', '1686855058'),
(912, 72, '_wp_desired_post_slug', '%d0%b2%d1%82%d0%be%d1%80%d0%be%d0%b9'),
(913, 24, '_wp_trash_meta_status', 'publish'),
(914, 24, '_wp_trash_meta_time', '1686855058'),
(915, 24, '_wp_desired_post_slug', '%d0%bf%d0%b5%d1%80%d0%b2%d0%b0%d1%8f') ;

#
# Конец содержимого данных таблицы `re_postmeta`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_posts`
#

DROP TABLE IF EXISTS `re_posts`;


#
# Структура таблицы `re_posts`
#

CREATE TABLE `re_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_posts`
#
INSERT INTO `re_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2023-05-29 12:20:15', '2023-05-29 09:20:15', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->', 'Привет, мир!', '', 'publish', 'open', 'open', '', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80', '', '', '2023-05-29 12:20:15', '2023-05-29 09:20:15', '', 0, 'http://realestate.000.pe/?p=1', 0, 'post', '', 1),
(2, 1, '2023-05-29 12:20:15', '2023-05-29 09:20:15', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href="http://realestate.000.pe/wp-admin/">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Пример страницы', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2023-05-29 12:20:15', '2023-05-29 09:20:15', '', 0, 'http://realestate.000.pe/?page_id=2', 0, 'page', '', 0),
(3, 1, '2023-05-29 12:20:15', '2023-05-29 09:20:15', '<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Наш адрес сайта: http://realestate.000.pe.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Комментарии</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email ("хеш") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Медиафайлы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куки</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность "Запомнить меня", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Встраиваемое содержимое других вебсайтов</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы запросите сброс пароля, ваш IP будет указан в email-сообщении о сбросе.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда отправляются ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph -->', 'Политика конфиденциальности', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2023-05-29 12:20:15', '2023-05-29 09:20:15', '', 0, 'http://realestate.000.pe/?page_id=3', 0, 'page', '', 0),
(5, 1, '2023-06-10 17:56:31', '2023-06-02 16:42:11', '', 'Home', '', 'publish', 'closed', 'closed', '', '%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f', '', '', '2023-06-10 17:56:31', '2023-06-10 14:56:31', '', 0, 'http://realestate.000.pe/?p=5', 1, 'nav_menu_item', '', 0),
(7, 1, '2023-06-03 12:35:11', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-06-03 12:35:11', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?p=7', 1, 'nav_menu_item', '', 0),
(8, 1, '2023-06-03 12:35:14', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-06-03 12:35:14', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?p=8', 1, 'nav_menu_item', '', 0),
(9, 1, '2023-06-03 12:35:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-06-03 12:35:17', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?p=9', 1, 'nav_menu_item', '', 0),
(10, 1, '2023-06-10 17:56:31', '2023-06-03 09:37:13', '', 'Properties', '', 'publish', 'closed', 'closed', '', 'properties', '', '', '2023-06-10 17:56:31', '2023-06-10 14:56:31', '', 0, 'http://realestate.000.pe/?p=10', 2, 'nav_menu_item', '', 0),
(11, 1, '2023-06-10 17:56:31', '2023-06-03 09:37:14', '', 'Property', '', 'publish', 'closed', 'closed', '', 'property', '', '', '2023-06-10 17:56:31', '2023-06-10 14:56:31', '', 0, 'http://realestate.000.pe/?p=11', 3, 'nav_menu_item', '', 0),
(12, 1, '2023-06-10 17:56:31', '2023-06-03 09:37:14', '', 'Template', '', 'publish', 'closed', 'closed', '', 'template', '', '', '2023-06-10 17:56:31', '2023-06-10 14:56:31', '', 0, 'http://realestate.000.pe/?p=12', 4, 'nav_menu_item', '', 0),
(13, 1, '2023-06-10 17:56:31', '2023-06-03 09:37:14', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2023-06-10 17:56:31', '2023-06-10 14:56:31', '', 0, 'http://realestate.000.pe/?p=13', 5, 'nav_menu_item', '', 0),
(17, 1, '2023-06-03 19:40:55', '2023-06-03 16:40:55', '', '1234', '', 'trash', 'closed', 'closed', '', '1234-2__trashed', '', '', '2023-06-03 19:41:28', '2023-06-03 16:41:28', '', 0, 'http://realestate.000.pe/?page_id=17', 0, 'page', '', 0),
(18, 1, '2023-06-03 19:40:55', '2023-06-03 16:40:55', '', '1234', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2023-06-03 19:40:55', '2023-06-03 16:40:55', '', 17, 'http://realestate.000.pe/?p=18', 0, 'revision', '', 0),
(21, 1, '2023-06-03 19:44:25', '2023-06-03 16:44:25', '', 'Главная', '', 'publish', 'closed', 'closed', '', '%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f', '', '', '2023-06-03 19:44:25', '2023-06-03 16:44:25', '', 0, 'http://realestate.000.pe/?page_id=21', 0, 'page', '', 0),
(22, 1, '2023-06-03 19:44:25', '2023-06-03 16:44:25', '', 'Главная', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2023-06-03 19:44:25', '2023-06-03 16:44:25', '', 21, 'http://realestate.000.pe/?p=22', 0, 'revision', '', 0),
(24, 1, '2023-06-05 12:58:51', '2023-06-05 09:58:51', 'йцукйкцййцук', 'first', 'йцукуйцкцукуйцуйкц', 'trash', 'closed', 'closed', '', '%d0%bf%d0%b5%d1%80%d0%b2%d0%b0%d1%8f__trashed', '', '', '2023-06-15 21:50:59', '2023-06-15 18:50:59', '', 0, 'http://realestate.000.pe/?post_type=property&#038;p=24', 0, 'property', '', 0),
(25, 1, '2023-06-05 13:36:44', '2023-06-05 10:36:44', '', 'property-1', '', 'inherit', 'open', 'closed', '', 'property-1', '', '', '2023-06-05 13:36:44', '2023-06-05 10:36:44', '', 24, 'http://realestate.000.pe/wp-content/uploads/2023/06/property-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(28, 1, '2023-06-06 19:26:53', '0000-00-00 00:00:00', '', 'PROPERTIES', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-06-06 19:26:53', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?p=28', 1, 'nav_menu_item', '', 0),
(29, 1, '2023-06-06 19:27:10', '0000-00-00 00:00:00', '', 'SERVICES', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-06-06 19:27:10', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?p=29', 1, 'nav_menu_item', '', 0),
(30, 1, '2023-06-06 19:27:28', '0000-00-00 00:00:00', '', 'SUBMIT PROPERTY', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-06-06 19:27:28', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?p=30', 1, 'nav_menu_item', '', 0),
(31, 1, '2023-06-06 19:27:42', '0000-00-00 00:00:00', '', 'CONTACT US', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-06-06 19:27:42', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?p=31', 1, 'nav_menu_item', '', 0),
(32, 1, '2023-06-06 19:27:52', '0000-00-00 00:00:00', '', 'FQA', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-06-06 19:27:52', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?p=32', 1, 'nav_menu_item', '', 0),
(33, 1, '2023-06-06 19:28:00', '0000-00-00 00:00:00', '', 'TERMS', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-06-06 19:28:00', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?p=33', 1, 'nav_menu_item', '', 0),
(34, 1, '2023-06-10 17:40:47', '2023-06-06 16:30:02', '', 'PROPERTIES', '', 'publish', 'closed', 'closed', '', 'properties-2', '', '', '2023-06-10 17:40:47', '2023-06-10 14:40:47', '', 0, 'http://realestate.000.pe/?p=34', 1, 'nav_menu_item', '', 0),
(35, 1, '2023-06-10 17:40:47', '2023-06-06 16:30:02', '', 'SERVICES', '', 'publish', 'closed', 'closed', '', 'services', '', '', '2023-06-10 17:40:47', '2023-06-10 14:40:47', '', 0, 'http://realestate.000.pe/?p=35', 2, 'nav_menu_item', '', 0),
(36, 1, '2023-06-10 17:40:47', '2023-06-06 16:30:02', '', 'SUBMIT PROPERTY', '', 'publish', 'closed', 'closed', '', 'submit-property', '', '', '2023-06-10 17:40:47', '2023-06-10 14:40:47', '', 0, 'http://realestate.000.pe/?p=36', 3, 'nav_menu_item', '', 0),
(37, 1, '2023-06-10 17:40:47', '2023-06-06 16:30:02', '', 'CONTACT US', '', 'publish', 'closed', 'closed', '', 'contact-us', '', '', '2023-06-10 17:40:47', '2023-06-10 14:40:47', '', 0, 'http://realestate.000.pe/?p=37', 4, 'nav_menu_item', '', 0),
(38, 1, '2023-06-10 17:40:47', '2023-06-06 16:30:02', '', 'FQA', '', 'publish', 'closed', 'closed', '', 'fqa', '', '', '2023-06-10 17:40:47', '2023-06-10 14:40:47', '', 0, 'http://realestate.000.pe/?p=38', 5, 'nav_menu_item', '', 0),
(39, 1, '2023-06-10 17:40:47', '2023-06-06 16:30:02', '', 'TERMS', '', 'publish', 'closed', 'closed', '', 'terms', '', '', '2023-06-10 17:40:47', '2023-06-10 14:40:47', '', 0, 'http://realestate.000.pe/?p=39', 6, 'nav_menu_item', '', 0),
(40, 1, '2023-06-10 17:40:24', '2023-06-06 16:31:20', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2023-06-10 17:40:24', '2023-06-10 14:40:24', '', 0, 'http://realestate.000.pe/?p=40', 1, 'nav_menu_item', '', 0),
(41, 1, '2023-06-10 17:40:24', '2023-06-06 16:31:20', '', 'Property', '', 'publish', 'closed', 'closed', '', 'property-2', '', '', '2023-06-10 17:40:24', '2023-06-10 14:40:24', '', 0, 'http://realestate.000.pe/?p=41', 2, 'nav_menu_item', '', 0),
(42, 1, '2023-06-10 17:40:24', '2023-06-06 16:31:20', '', 'Faq', '', 'publish', 'closed', 'closed', '', 'faq', '', '', '2023-06-10 17:40:24', '2023-06-10 14:40:24', '', 0, 'http://realestate.000.pe/?p=42', 3, 'nav_menu_item', '', 0),
(43, 1, '2023-06-10 17:40:24', '2023-06-06 16:31:21', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact-2', '', '', '2023-06-10 17:40:24', '2023-06-10 14:40:24', '', 0, 'http://realestate.000.pe/?p=43', 4, 'nav_menu_item', '', 0),
(44, 1, '2023-06-10 16:38:24', '2023-06-10 13:38:24', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:8:"property";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Properties', 'properties', 'publish', 'closed', 'closed', '', 'group_64847c2f4b608', '', '', '2023-06-15 16:59:46', '2023-06-15 13:59:46', '', 0, 'http://realestate.000.pe/?post_type=acf-field-group&#038;p=44', 0, 'acf-field-group', '', 0),
(45, 1, '2023-06-10 16:38:24', '2023-06-10 13:38:24', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:6:"number";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";i:0;s:3:"min";s:0:"";s:3:"max";s:0:"";s:11:"placeholder";s:0:"";s:4:"step";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Price', 'price', 'publish', 'closed', 'closed', '', 'field_64847c2feb7fc', '', '', '2023-06-10 16:38:24', '2023-06-10 13:38:24', '', 44, 'http://realestate.000.pe/?post_type=acf-field&p=45', 0, 'acf-field', '', 0),
(46, 1, '2023-06-10 16:38:24', '2023-06-10 13:38:24', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:6:"number";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";i:0;s:3:"min";s:0:"";s:3:"max";s:0:"";s:11:"placeholder";s:0:"";s:4:"step";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Area', 'area', 'publish', 'closed', 'closed', '', 'field_64847c59eb7fd', '', '', '2023-06-10 16:38:24', '2023-06-10 13:38:24', '', 44, 'http://realestate.000.pe/?post_type=acf-field&p=46', 1, 'acf-field', '', 0),
(47, 1, '2023-06-10 16:50:29', '2023-06-10 13:50:29', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:6:"number";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";i:0;s:3:"min";s:0:"";s:3:"max";s:0:"";s:11:"placeholder";s:0:"";s:4:"step";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'bath_room', 'bath_room', 'publish', 'closed', 'closed', '', 'field_64847f2f2ea18', '', '', '2023-06-10 16:52:57', '2023-06-10 13:52:57', '', 44, 'http://realestate.000.pe/?post_type=acf-field&#038;p=47', 3, 'acf-field', '', 0),
(48, 1, '2023-06-10 16:50:29', '2023-06-10 13:50:29', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:6:"number";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";i:0;s:3:"min";s:0:"";s:3:"max";s:0:"";s:11:"placeholder";s:0:"";s:4:"step";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'bed_room', 'bed_room', 'publish', 'closed', 'closed', '', 'field_64847f562ea19', '', '', '2023-06-10 16:52:57', '2023-06-10 13:52:57', '', 44, 'http://realestate.000.pe/?post_type=acf-field&#038;p=48', 2, 'acf-field', '', 0),
(49, 1, '2023-06-10 16:50:29', '2023-06-10 13:50:29', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:6:"number";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";i:0;s:3:"min";s:0:"";s:3:"max";s:0:"";s:11:"placeholder";s:0:"";s:4:"step";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'garage', 'garage', 'publish', 'closed', 'closed', '', 'field_64847f852ea1a', '', '', '2023-06-10 16:50:29', '2023-06-10 13:50:29', '', 44, 'http://realestate.000.pe/?post_type=acf-field&p=49', 4, 'acf-field', '', 0),
(50, 1, '2023-06-10 17:04:32', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-06-10 17:04:32', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?p=50', 0, 'post', '', 0),
(51, 1, '2023-06-10 17:04:51', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-06-10 17:04:51', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?post_type=property&p=51', 0, 'property', '', 0),
(52, 1, '2023-06-10 17:05:35', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-06-10 17:05:35', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?post_type=property&p=52', 0, 'property', '', 0),
(53, 1, '2023-06-10 17:23:21', '2023-06-10 14:23:21', '', 'Главная - Українська', '', 'publish', 'closed', 'closed', '', '%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f-%d1%83%d0%ba%d1%80%d0%b0%d1%97%d0%bd%d1%81%d1%8c%d0%ba%d0%b0', '', '', '2023-06-10 17:55:36', '2023-06-10 14:55:36', '', 0, 'http://realestate.000.pe/%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f-%d1%83%d0%ba%d1%80%d0%b0%d1%97%d0%bd%d1%81%d1%8c%d0%ba%d0%b0/', 0, 'page', '', 0),
(54, 1, '2023-06-10 17:30:22', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-06-10 17:30:22', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?post_type=property&p=54', 0, 'property', '', 0),
(55, 1, '2023-06-10 17:30:39', '2023-06-10 14:30:39', 'Nulla quis dapibus nisl. Suspendisse ultricies Nulla quis dapibus nisl. Suspendisse ultricies commodo arcu nec pretium. Nullam sed arcu ultricies commodo arcu nec pretium. Nullam sed arcu ultricies Nulla quis dapibus nisl. Suspendisse ultricies commodo arcu nec pretium. Nullam sed arcu ultricies Nulla quis dapibus nisl. Suspendisse ultricies commodo arcu nec pretium. Nullam sed arcu ultricies', 'Перша', '', 'publish', 'closed', 'closed', '', '%d0%bf%d0%b5%d1%80%d1%88%d0%b0', '', '', '2023-06-15 18:41:28', '2023-06-15 15:41:28', '', 0, 'http://realestate.000.pe/?post_type=property&#038;p=55', 0, 'property', '', 0),
(56, 1, '2023-06-10 17:56:31', '2023-06-10 14:36:51', '', 'Языки', '', 'publish', 'closed', 'closed', '', '%d1%8f%d0%b7%d1%8b%d0%ba%d0%b8', '', '', '2023-06-10 17:56:31', '2023-06-10 14:56:31', '', 0, 'http://realestate.000.pe/?p=56', 6, 'nav_menu_item', '', 0),
(57, 1, '2023-06-10 17:55:17', '2023-06-10 14:55:17', '', 'Главная - Українська', '', 'inherit', 'closed', 'closed', '', '53-revision-v1', '', '', '2023-06-10 17:55:17', '2023-06-10 14:55:17', '', 53, 'http://realestate.000.pe/?p=57', 0, 'revision', '', 0),
(59, 1, '2023-06-13 12:52:46', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-06-13 12:52:46', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?post_type=property&p=59', 0, 'property', '', 0),
(60, 1, '2023-06-13 13:06:36', '2023-06-13 10:06:36', '', 'property-1', '', 'inherit', 'open', 'closed', '', 'property-1-2', '', '', '2023-06-13 13:06:36', '2023-06-13 10:06:36', '', 55, 'http://realestate.000.pe/wp-content/uploads/2023/06/property-1-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(61, 1, '2023-06-13 13:06:37', '2023-06-13 10:06:37', '', 'property-2', '', 'inherit', 'open', 'closed', '', 'property-2-2', '', '', '2023-06-13 13:06:37', '2023-06-13 10:06:37', '', 55, 'http://realestate.000.pe/wp-content/uploads/2023/06/property-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(62, 1, '2023-06-13 13:06:38', '2023-06-13 10:06:38', '', 'property-3', '', 'inherit', 'open', 'closed', '', 'property-3', '', '', '2023-06-13 13:06:38', '2023-06-13 10:06:38', '', 55, 'http://realestate.000.pe/wp-content/uploads/2023/06/property-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(63, 1, '2023-06-13 13:07:56', '2023-06-13 10:07:56', '<img class="alignnone size-medium wp-image-61" src="http://realestate.000.pe/wp-content/uploads/2023/06/property-2-300x245.jpg" alt="" width="300" height="245" /><img class="alignnone size-medium wp-image-60" src="http://realestate.000.pe/wp-content/uploads/2023/06/property-1-1-300x245.jpg" alt="" width="300" height="245" />', 'Перша', '', 'inherit', 'closed', 'closed', '', '55-autosave-v1', '', '', '2023-06-13 13:07:56', '2023-06-13 10:07:56', '', 55, 'http://realestate.000.pe/?p=63', 0, 'revision', '', 0),
(64, 1, '2023-06-13 13:08:04', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-06-13 13:08:04', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?post_type=acf-field-group&p=64', 0, 'acf-field-group', '', 0),
(65, 1, '2023-06-13 13:18:19', '2023-06-13 10:18:19', 'a:14:{s:10:"aria-label";s:0:"";s:4:"type";s:6:"select";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:2:{s:4:"sell";s:4:"sell";s:4:"rent";s:4:"rent";}s:13:"default_value";b:0;s:13:"return_format";s:5:"value";s:8:"multiple";i:0;s:10:"allow_null";i:0;s:2:"ui";i:0;s:4:"ajax";i:0;s:11:"placeholder";s:0:"";}', 'status', 'status', 'publish', 'closed', 'closed', '', 'field_6488417e1fc4e', '', '', '2023-06-14 19:32:48', '2023-06-14 16:32:48', '', 44, 'http://realestate.000.pe/?post_type=acf-field&#038;p=65', 5, 'acf-field', '', 0),
(66, 1, '2023-06-13 13:18:19', '2023-06-13 10:18:19', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'waterfront', 'waterfront', 'publish', 'closed', 'closed', '', 'field_6488422d1fc50', '', '', '2023-06-13 13:18:19', '2023-06-13 10:18:19', '', 44, 'http://realestate.000.pe/?post_type=acf-field&p=66', 6, 'acf-field', '', 0),
(67, 1, '2023-06-13 13:18:20', '2023-06-13 10:18:20', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'built_in', 'built_in', 'publish', 'closed', 'closed', '', 'field_6488423d1fc51', '', '', '2023-06-13 13:18:20', '2023-06-13 10:18:20', '', 44, 'http://realestate.000.pe/?post_type=acf-field&p=67', 7, 'acf-field', '', 0),
(68, 1, '2023-06-13 13:18:20', '2023-06-13 10:18:20', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'parking', 'parking', 'publish', 'closed', 'closed', '', 'field_648842491fc52', '', '', '2023-06-13 13:18:20', '2023-06-13 10:18:20', '', 44, 'http://realestate.000.pe/?post_type=acf-field&p=68', 8, 'acf-field', '', 0),
(69, 1, '2023-06-13 13:18:20', '2023-06-13 10:18:20', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'view', 'view', 'publish', 'closed', 'closed', '', 'field_648842551fc53', '', '', '2023-06-13 13:18:20', '2023-06-13 10:18:20', '', 44, 'http://realestate.000.pe/?post_type=acf-field&p=69', 9, 'acf-field', '', 0),
(70, 1, '2023-06-13 13:21:51', '2023-06-13 10:21:51', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:12:"preview_size";s:6:"medium";}', 'image1', 'image1', 'publish', 'closed', 'closed', '', 'field_6488432815fe8', '', '', '2023-06-15 16:22:19', '2023-06-15 13:22:19', '', 44, 'http://realestate.000.pe/?post_type=acf-field&#038;p=70', 10, 'acf-field', '', 0),
(71, 1, '2023-06-13 13:25:18', '2023-06-13 10:25:18', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:12:"preview_size";s:6:"medium";}', 'image2', 'image2', 'publish', 'closed', 'closed', '', 'field_648843fa0c84b', '', '', '2023-06-15 16:59:46', '2023-06-15 13:59:46', '', 44, 'http://realestate.000.pe/?post_type=acf-field&#038;p=71', 11, 'acf-field', '', 0),
(72, 1, '2023-06-13 16:51:29', '2023-06-13 13:51:29', '123545', 'Второй villa', '', 'trash', 'closed', 'closed', '', '%d0%b2%d1%82%d0%be%d1%80%d0%be%d0%b9__trashed', '', '', '2023-06-15 21:50:58', '2023-06-15 18:50:58', '', 0, 'http://realestate.000.pe/?post_type=property&#038;p=72', 0, 'property', '', 0),
(73, 1, '2023-06-13 17:17:13', '2023-06-13 14:17:13', '', 'property1', '', 'inherit', 'open', 'closed', '', 'property1', '', '', '2023-06-13 17:17:13', '2023-06-13 14:17:13', '', 55, 'http://realestate.000.pe/wp-content/uploads/2023/06/property1.jpg', 0, 'attachment', 'image/jpeg', 0),
(74, 1, '2023-06-13 17:17:29', '2023-06-13 14:17:29', '', 'property3', '', 'inherit', 'open', 'closed', '', 'property3', '', '', '2023-06-13 17:17:29', '2023-06-13 14:17:29', '', 55, 'http://realestate.000.pe/wp-content/uploads/2023/06/property3.jpg', 0, 'attachment', 'image/jpeg', 0),
(75, 1, '2023-06-13 17:19:33', '2023-06-13 14:19:33', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:12:"preview_size";s:6:"medium";}', 'image3', 'image3', 'publish', 'closed', 'closed', '', 'field_64887ae127b6e', '', '', '2023-06-13 17:19:33', '2023-06-13 14:19:33', '', 44, 'http://realestate.000.pe/?post_type=acf-field&p=75', 12, 'acf-field', '', 0),
(76, 1, '2023-06-13 17:19:49', '2023-06-13 14:19:49', '', 'property2', '', 'inherit', 'open', 'closed', '', 'property2', '', '', '2023-06-13 17:19:49', '2023-06-13 14:19:49', '', 55, 'http://realestate.000.pe/wp-content/uploads/2023/06/property2.jpg', 0, 'attachment', 'image/jpeg', 0),
(77, 1, '2023-06-13 19:19:53', '2023-06-13 16:19:53', '', 'countdown_-_2637 (540p)', '', 'inherit', 'open', 'closed', '', 'countdown_-_2637-540p', '', '', '2023-06-13 19:19:53', '2023-06-13 16:19:53', '', 55, 'http://realestate.000.pe/wp-content/uploads/2023/06/countdown_-_2637-540p.mp4', 0, 'attachment', 'video/mp4', 0),
(78, 1, '2023-06-13 21:52:28', '2023-06-13 18:52:28', '', 'третий', '', 'trash', 'closed', 'closed', '', '%d1%82%d1%80%d0%b5%d1%82%d0%b8%d0%b9__trashed', '', '', '2023-06-15 21:50:58', '2023-06-15 18:50:58', '', 0, 'http://realestate.000.pe/?post_type=property&#038;p=78', 0, 'property', '', 0),
(79, 1, '2023-06-13 21:52:24', '2023-06-13 18:52:24', '', 'small-property-3', '', 'inherit', 'open', 'closed', '', 'small-property-3', '', '', '2023-06-13 21:52:24', '2023-06-13 18:52:24', '', 78, 'http://realestate.000.pe/wp-content/uploads/2023/06/small-property-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(80, 1, '2023-06-14 22:03:27', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-06-14 22:03:27', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?p=80', 0, 'post', '', 0),
(81, 2, '2023-06-15 20:36:05', '2023-06-15 17:36:05', '', 'Черновик', '', 'trash', 'open', 'open', '', '__trashed', '', '', '2023-06-15 20:36:05', '2023-06-15 17:36:05', '', 0, 'http://realestate.000.pe/?p=81', 0, 'post', '', 0),
(82, 1, '2023-06-15 11:53:06', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-06-15 11:53:06', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?page_id=82', 0, 'page', '', 0),
(83, 1, '2023-06-15 11:59:53', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-06-15 11:59:53', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?post_type=acf-post-type&p=83', 0, 'acf-post-type', '', 0),
(84, 1, '2023-06-15 12:04:01', '2023-06-15 09:04:01', '[[[{"field_key":"user_login","general_setting":{"label":"Username","field_name":"user_login","placeholder":"","required":"yes"},"advance_setting":[]},{"field_key":"user_pass","general_setting":{"label":"User Password","field_name":"user_pass","placeholder":"","required":"yes"},"advance_setting":[]}],[{"field_key":"user_email","general_setting":{"label":"User Email","field_name":"user_email","placeholder":"","required":"yes"},"advance_setting":[]},{"field_key":"user_confirm_password","general_setting":{"label":"Confirm Password","field_name":"user_confirm_password","placeholder":"","required":"yes"},"advance_setting":[]}]]]', 'Default form', '', 'publish', 'closed', 'closed', '', 'default-form', '', '', '2023-06-15 12:04:01', '2023-06-15 09:04:01', '', 0, 'http://realestate.000.pe/?post_type=user_registration&p=84', 0, 'user_registration', '', 0),
(85, 1, '2023-06-15 12:04:25', '2023-06-15 09:04:25', '[user_registration_form id="84"]', 'Registration', '', 'trash', 'closed', 'closed', '', 'registration__trashed', '', '', '2023-06-15 12:26:27', '2023-06-15 09:26:27', '', 0, 'http://realestate.000.pe/registration/', 0, 'page', '', 0),
(86, 1, '2023-06-15 12:04:25', '2023-06-15 09:04:25', '[user_registration_my_account]', 'My Account', '', 'trash', 'closed', 'closed', '', 'my-account__trashed', '', '', '2023-06-15 12:26:27', '2023-06-15 09:26:27', '', 0, 'http://realestate.000.pe/my-account/', 0, 'page', '', 0),
(87, 1, '2023-06-15 12:26:27', '2023-06-15 09:26:27', '[user_registration_my_account]', 'My Account', '', 'inherit', 'closed', 'closed', '', '86-revision-v1', '', '', '2023-06-15 12:26:27', '2023-06-15 09:26:27', '', 86, 'http://realestate.000.pe/?p=87', 0, 'revision', '', 0),
(88, 1, '2023-06-15 12:26:27', '2023-06-15 09:26:27', '[user_registration_form id="84"]', 'Registration', '', 'inherit', 'closed', 'closed', '', '85-revision-v1', '', '', '2023-06-15 12:26:27', '2023-06-15 09:26:27', '', 85, 'http://realestate.000.pe/?p=88', 0, 'revision', '', 0),
(89, 1, '2023-06-15 12:26:33', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-06-15 12:26:33', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?page_id=89', 0, 'page', '', 0),
(90, 1, '2023-06-15 12:28:25', '2023-06-15 09:28:25', '', 'New property', '', 'publish', 'closed', 'closed', '', 'new-property', '', '', '2023-06-15 12:28:27', '2023-06-15 09:28:27', '', 0, 'http://realestate.000.pe/?page_id=90', 0, 'page', '', 0),
(91, 1, '2023-06-15 12:28:25', '2023-06-15 09:28:25', '', 'New property', '', 'inherit', 'closed', 'closed', '', '90-revision-v1', '', '', '2023-06-15 12:28:25', '2023-06-15 09:28:25', '', 90, 'http://realestate.000.pe/?p=91', 0, 'revision', '', 0),
(92, 1, '2023-06-15 12:33:40', '2023-06-15 09:33:40', 'Четвертый 12323', 'Четвертый', '', 'trash', 'closed', 'closed', '', '%d1%87%d0%b5%d1%82%d0%b2%d0%b5%d1%80%d1%82%d1%8b%d0%b9__trashed', '', '', '2023-06-15 14:25:25', '2023-06-15 11:25:25', '', 0, 'http://realestate.000.pe/properties/%d1%87%d0%b5%d1%82%d0%b2%d0%b5%d1%80%d1%82%d1%8b%d0%b9/', 0, 'property', '', 0),
(93, 1, '2023-06-15 12:36:19', '2023-06-15 09:36:19', 'уцйуйц', 'йцйуц', '', 'trash', 'closed', 'closed', '', '%d0%b9%d1%86%d0%b9%d1%83%d1%86__trashed', '', '', '2023-06-15 14:25:25', '2023-06-15 11:25:25', '', 0, 'http://realestate.000.pe/properties/%d0%b9%d1%86%d0%b9%d1%83%d1%86/', 0, 'property', '', 0),
(94, 1, '2023-06-15 12:52:01', '2023-06-15 09:52:01', 'Five', 'Five', '', 'trash', 'closed', 'closed', '', 'five__trashed', '', '', '2023-06-15 14:25:25', '2023-06-15 11:25:25', '', 0, 'http://realestate.000.pe/properties/five/', 0, 'property', '', 0),
(95, 1, '2023-06-15 13:56:37', '2023-06-15 10:56:37', 'villa', 'six', '', 'trash', 'closed', 'closed', '', 'six__trashed', '', '', '2023-06-15 14:25:25', '2023-06-15 11:25:25', '', 0, 'http://realestate.000.pe/properties/six/', 0, 'property', '', 0),
(96, 1, '2023-06-15 14:14:47', '2023-06-15 11:14:47', 'seven', 'villa', '', 'trash', 'closed', 'closed', '', 'villa__trashed', '', '', '2023-06-15 14:25:24', '2023-06-15 11:25:24', '', 0, 'http://realestate.000.pe/properties/villa/', 0, 'property', '', 0),
(97, 1, '2023-06-15 14:17:53', '2023-06-15 11:17:53', '1234', 'qwerty1234', '', 'trash', 'closed', 'closed', '', 'qwerty1234__trashed', '', '', '2023-06-15 14:25:24', '2023-06-15 11:25:24', '', 0, 'http://realestate.000.pe/properties/qwerty1234/', 0, 'property', '', 0),
(98, 1, '2023-06-15 14:19:24', '2023-06-15 11:19:24', '', 'qw12', '', 'trash', 'closed', 'closed', '', 'qw12__trashed', '', '', '2023-06-15 14:25:23', '2023-06-15 11:25:23', '', 0, 'http://realestate.000.pe/properties/qw12/', 0, 'property', '', 0),
(99, 1, '2023-06-15 14:24:32', '2023-06-15 11:24:32', '', 'аывавыаыв', '', 'trash', 'closed', 'closed', '', '%d0%b0%d1%8b%d0%b2%d0%b0%d0%b2%d1%8b%d0%b0%d1%8b%d0%b2__trashed', '', '', '2023-06-15 14:25:23', '2023-06-15 11:25:23', '', 0, 'http://realestate.000.pe/properties/%d0%b0%d1%8b%d0%b2%d0%b0%d0%b2%d1%8b%d0%b0%d1%8b%d0%b2/', 0, 'property', '', 0),
(100, 1, '2023-06-15 14:24:33', '2023-06-15 11:24:33', '', 'property-5', '', 'inherit', 'open', 'closed', '', 'property-5', '', '', '2023-06-15 14:24:33', '2023-06-15 11:24:33', '', 99, 'http://realestate.000.pe/wp-content/uploads/2023/06/property-5.jpg', 0, 'attachment', 'image/jpeg', 0),
(101, 1, '2023-06-15 14:31:33', '2023-06-15 11:31:33', '', 'Villa the best', '', 'trash', 'closed', 'closed', '', 'villa-the-best__trashed', '', '', '2023-06-15 18:30:17', '2023-06-15 15:30:17', '', 0, 'http://realestate.000.pe/properties/villa-the-best/', 0, 'property', '', 0),
(102, 1, '2023-06-15 14:31:34', '2023-06-15 11:31:34', '', 'property-4', '', 'inherit', 'open', 'closed', '', 'property-4', '', '', '2023-06-15 14:31:34', '2023-06-15 11:31:34', '', 101, 'http://realestate.000.pe/wp-content/uploads/2023/06/property-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(103, 1, '2023-06-15 14:33:38', '2023-06-15 11:33:38', '', 'idk', '', 'trash', 'closed', 'closed', '', 'idk__trashed', '', '', '2023-06-15 18:30:17', '2023-06-15 15:30:17', '', 0, 'http://realestate.000.pe/properties/idk/', 0, 'property', '', 0),
(104, 1, '2023-06-15 14:33:39', '2023-06-15 11:33:39', '', 'property4', '', 'inherit', 'open', 'closed', '', 'property4', '', '', '2023-06-15 14:33:39', '2023-06-15 11:33:39', '', 103, 'http://realestate.000.pe/wp-content/uploads/2023/06/property4.jpg', 0, 'attachment', 'image/jpeg', 0),
(105, 1, '2023-06-15 14:34:01', '2023-06-15 11:34:01', '', 'Villa the best', '', 'inherit', 'closed', 'closed', '', '101-autosave-v1', '', '', '2023-06-15 14:34:01', '2023-06-15 11:34:01', '', 101, 'http://realestate.000.pe/?p=105', 0, 'revision', '', 0),
(106, 3, '2023-06-15 20:36:07', '2023-06-15 17:36:07', '', 'Черновик', '', 'trash', 'open', 'open', '', '__trashed-2', '', '', '2023-06-15 20:36:07', '2023-06-15 17:36:07', '', 0, 'http://realestate.000.pe/?p=106', 0, 'post', '', 0),
(107, 3, '2023-06-15 14:38:14', '2023-06-15 11:38:14', '', 'VILLA 123', '', 'trash', 'closed', 'closed', '', 'villa-123__trashed', '', '', '2023-06-15 18:30:17', '2023-06-15 15:30:17', '', 0, 'http://realestate.000.pe/properties/villa-123/', 0, 'property', '', 0),
(110, 1, '2023-06-15 16:24:04', '2023-06-15 13:24:04', '', 'ошвфыош', '', 'trash', 'closed', 'closed', '', '%d0%be%d1%88%d0%b2%d1%84%d1%8b%d0%be%d1%88__trashed', '', '', '2023-06-15 18:30:16', '2023-06-15 15:30:16', '', 0, 'http://realestate.000.pe/properties/%d0%be%d1%88%d0%b2%d1%84%d1%8b%d0%be%d1%88/', 0, 'property', '', 0),
(111, 1, '2023-06-15 16:24:04', '2023-06-15 13:24:04', '', 'property1', '', 'inherit', 'open', 'closed', '', 'property1-3', '', '', '2023-06-15 16:24:04', '2023-06-15 13:24:04', '', 110, 'http://realestate.000.pe/wp-content/uploads/2023/06/property1-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(112, 1, '2023-06-15 16:24:05', '2023-06-15 13:24:05', '', 'property3', '', 'inherit', 'open', 'closed', '', 'property3-2', '', '', '2023-06-15 16:24:05', '2023-06-15 13:24:05', '', 110, 'http://realestate.000.pe/wp-content/uploads/2023/06/property3-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(113, 1, '2023-06-15 16:24:42', '2023-06-15 13:24:42', '', 'йцйцй', '', 'trash', 'closed', 'closed', '', '%d0%b9%d1%86%d0%b9%d1%86%d0%b9__trashed', '', '', '2023-06-15 18:30:16', '2023-06-15 15:30:16', '', 0, 'http://realestate.000.pe/properties/%d0%b9%d1%86%d0%b9%d1%86%d0%b9/', 0, 'property', '', 0) ;
INSERT INTO `re_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(114, 1, '2023-06-15 16:24:43', '2023-06-15 13:24:43', '', 'property2', '', 'inherit', 'open', 'closed', '', 'property2-3', '', '', '2023-06-15 16:24:43', '2023-06-15 13:24:43', '', 113, 'http://realestate.000.pe/wp-content/uploads/2023/06/property2-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(115, 1, '2023-06-15 16:24:43', '2023-06-15 13:24:43', '', 'property4', '', 'inherit', 'open', 'closed', '', 'property4-2', '', '', '2023-06-15 16:24:43', '2023-06-15 13:24:43', '', 113, 'http://realestate.000.pe/wp-content/uploads/2023/06/property4-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(116, 1, '2023-06-15 16:24:44', '2023-06-15 13:24:44', '', 'property1', '', 'inherit', 'open', 'closed', '', 'property1-4', '', '', '2023-06-15 16:24:44', '2023-06-15 13:24:44', '', 113, 'http://realestate.000.pe/wp-content/uploads/2023/06/property1-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(117, 1, '2023-06-15 17:00:28', '2023-06-15 14:00:28', '', '54554', '', 'trash', 'closed', 'closed', '', '54554__trashed', '', '', '2023-06-15 18:30:16', '2023-06-15 15:30:16', '', 0, 'http://realestate.000.pe/properties/54554/', 0, 'property', '', 0),
(118, 1, '2023-06-15 17:00:28', '2023-06-15 14:00:28', '', 'property2', '', 'inherit', 'open', 'closed', '', 'property2-4', '', '', '2023-06-15 17:00:28', '2023-06-15 14:00:28', '', 117, 'http://realestate.000.pe/wp-content/uploads/2023/06/property2-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(119, 1, '2023-06-15 17:00:29', '2023-06-15 14:00:29', '', 'property3', '', 'inherit', 'open', 'closed', '', 'property3-3', '', '', '2023-06-15 17:00:29', '2023-06-15 14:00:29', '', 117, 'http://realestate.000.pe/wp-content/uploads/2023/06/property3-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(120, 1, '2023-06-15 17:00:30', '2023-06-15 14:00:30', '', 'property4', '', 'inherit', 'open', 'closed', '', 'property4-3', '', '', '2023-06-15 17:00:30', '2023-06-15 14:00:30', '', 117, 'http://realestate.000.pe/wp-content/uploads/2023/06/property4-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(121, 1, '2023-06-15 18:35:06', '2023-06-15 15:35:06', '', 'property3', '', 'inherit', 'open', 'closed', '', 'property3-4', '', '', '2023-06-15 18:35:06', '2023-06-15 15:35:06', '', 55, 'http://realestate.000.pe/wp-content/uploads/2023/06/property3-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(122, 1, '2023-06-15 18:35:35', '2023-06-15 15:35:35', '', 'property4', '', 'inherit', 'open', 'closed', '', 'property4-4', '', '', '2023-06-15 18:35:35', '2023-06-15 15:35:35', '', 55, 'http://realestate.000.pe/wp-content/uploads/2023/06/property4-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(123, 1, '2023-06-15 18:37:00', '2023-06-15 15:37:00', '', '5431', '', 'trash', 'closed', 'closed', '', '5431__trashed', '', '', '2023-06-15 20:26:30', '2023-06-15 17:26:30', '', 0, 'http://realestate.000.pe/properties/5431/', 0, 'property', '', 0),
(124, 1, '2023-06-15 18:37:00', '2023-06-15 15:37:00', '', 'property1', '', 'inherit', 'open', 'closed', '', 'property1-5', '', '', '2023-06-15 18:37:00', '2023-06-15 15:37:00', '', 123, 'http://realestate.000.pe/wp-content/uploads/2023/06/property1-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(125, 1, '2023-06-15 18:37:01', '2023-06-15 15:37:01', '', 'property2', '', 'inherit', 'open', 'closed', '', 'property2-5', '', '', '2023-06-15 18:37:01', '2023-06-15 15:37:01', '', 123, 'http://realestate.000.pe/wp-content/uploads/2023/06/property2-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(126, 1, '2023-06-15 18:37:02', '2023-06-15 15:37:02', '', 'property3', '', 'inherit', 'open', 'closed', '', 'property3-5', '', '', '2023-06-15 18:37:02', '2023-06-15 15:37:02', '', 123, 'http://realestate.000.pe/wp-content/uploads/2023/06/property3-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(127, 1, '2023-06-15 18:43:10', '2023-06-15 15:43:10', '', 'пвап', '', 'trash', 'closed', 'closed', '', '%d0%bf%d0%b2%d0%b0%d0%bf__trashed', '', '', '2023-06-15 20:26:30', '2023-06-15 17:26:30', '', 0, 'http://realestate.000.pe/properties/%d0%bf%d0%b2%d0%b0%d0%bf/', 0, 'property', '', 0),
(128, 1, '2023-06-15 18:43:11', '2023-06-15 15:43:11', '', 'pngegg', '', 'inherit', 'open', 'closed', '', 'pngegg', '', '', '2023-06-15 18:43:11', '2023-06-15 15:43:11', '', 127, 'http://realestate.000.pe/wp-content/uploads/2023/06/pngegg.png', 0, 'attachment', 'image/png', 0),
(129, 1, '2023-06-15 18:43:11', '2023-06-15 15:43:11', '', 'pngegg (1)', '', 'inherit', 'open', 'closed', '', 'pngegg-1', '', '', '2023-06-15 18:43:11', '2023-06-15 15:43:11', '', 127, 'http://realestate.000.pe/wp-content/uploads/2023/06/pngegg-1.png', 0, 'attachment', 'image/png', 0),
(130, 1, '2023-06-15 19:20:39', '2023-06-15 16:20:39', 'qwwerty com', 'QWERTY', '', 'trash', 'closed', 'closed', '', 'qwerty__trashed', '', '', '2023-06-15 20:26:30', '2023-06-15 17:26:30', '', 0, 'http://realestate.000.pe/properties/qwerty/', 0, 'property', '', 0),
(131, 1, '2023-06-15 19:20:39', '2023-06-15 16:20:39', '', 'property-1', '', 'inherit', 'open', 'closed', '', 'property-1-3', '', '', '2023-06-15 19:20:39', '2023-06-15 16:20:39', '', 130, 'http://realestate.000.pe/wp-content/uploads/2023/06/property-1-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(132, 1, '2023-06-15 19:20:40', '2023-06-15 16:20:40', '', 'property1', '', 'inherit', 'open', 'closed', '', 'property1-6', '', '', '2023-06-15 19:20:40', '2023-06-15 16:20:40', '', 130, 'http://realestate.000.pe/wp-content/uploads/2023/06/property1-5.jpg', 0, 'attachment', 'image/jpeg', 0),
(133, 1, '2023-06-15 19:20:41', '2023-06-15 16:20:41', '', 'property2', '', 'inherit', 'open', 'closed', '', 'property2-6', '', '', '2023-06-15 19:20:41', '2023-06-15 16:20:41', '', 130, 'http://realestate.000.pe/wp-content/uploads/2023/06/property2-5.jpg', 0, 'attachment', 'image/jpeg', 0),
(134, 1, '2023-06-15 19:20:41', '2023-06-15 16:20:41', '', 'property3', '', 'inherit', 'open', 'closed', '', 'property3-6', '', '', '2023-06-15 19:20:41', '2023-06-15 16:20:41', '', 130, 'http://realestate.000.pe/wp-content/uploads/2023/06/property3-5.jpg', 0, 'attachment', 'image/jpeg', 0),
(135, 1, '2023-06-15 19:24:52', '2023-06-15 16:24:52', '', '12121', '', 'trash', 'closed', 'closed', '', '12121__trashed', '', '', '2023-06-15 20:26:29', '2023-06-15 17:26:29', '', 0, 'http://realestate.000.pe/properties/12121/', 0, 'property', '', 0),
(136, 1, '2023-06-15 19:28:01', '2023-06-15 16:28:01', '', '3232', '', 'trash', 'closed', 'closed', '', '3232__trashed', '', '', '2023-06-15 20:26:29', '2023-06-15 17:26:29', '', 0, 'http://realestate.000.pe/properties/3232/', 0, 'property', '', 0),
(137, 1, '2023-06-15 19:31:03', '2023-06-15 16:31:03', '', '21214243', '', 'trash', 'closed', 'closed', '', '21214243__trashed', '', '', '2023-06-15 20:26:29', '2023-06-15 17:26:29', '', 0, 'http://realestate.000.pe/properties/21214243/', 0, 'property', '', 0),
(138, 1, '2023-06-15 19:52:42', '2023-06-15 16:52:42', '', '545454', '', 'trash', 'closed', 'closed', '', '545454__trashed', '', '', '2023-06-15 20:26:28', '2023-06-15 17:26:28', '', 0, 'http://realestate.000.pe/properties/545454/', 0, 'property', '', 0),
(139, 4, '2023-06-15 20:30:18', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-06-15 20:30:18', '0000-00-00 00:00:00', '', 0, 'http://realestate.000.pe/?p=139', 0, 'post', '', 0),
(140, 1, '2023-06-15 20:36:05', '2023-06-15 17:36:05', '', 'Черновик', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2023-06-15 20:36:05', '2023-06-15 17:36:05', '', 81, 'http://realestate.000.pe/?p=140', 0, 'revision', '', 0),
(141, 1, '2023-06-15 20:36:07', '2023-06-15 17:36:07', '', 'Черновик', '', 'inherit', 'closed', 'closed', '', '106-revision-v1', '', '', '2023-06-15 20:36:07', '2023-06-15 17:36:07', '', 106, 'http://realestate.000.pe/?p=141', 0, 'revision', '', 0),
(142, 4, '2023-06-15 20:39:55', '2023-06-15 17:39:55', '', 'qwerty', '', 'trash', 'closed', 'closed', '', 'qwerty__trashed-2', '', '', '2023-06-15 21:50:57', '2023-06-15 18:50:57', '', 0, 'http://realestate.000.pe/properties/qwerty/', 0, 'property', '', 0),
(143, 4, '2023-06-15 20:59:02', '2023-06-15 17:59:02', '', 'qweqweqw', '', 'trash', 'closed', 'closed', '', 'qweqweqw__trashed', '', '', '2023-06-15 21:50:57', '2023-06-15 18:50:57', '', 0, 'http://realestate.000.pe/properties/qweqweqw/', 0, 'property', '', 0),
(144, 4, '2023-06-15 21:03:22', '2023-06-15 18:03:22', '', '231321', '', 'trash', 'closed', 'closed', '', '231321__trashed', '', '', '2023-06-15 21:50:57', '2023-06-15 18:50:57', '', 0, 'http://realestate.000.pe/properties/231321/', 0, 'property', '', 0),
(145, 4, '2023-06-15 21:05:22', '2023-06-15 18:05:22', '', '12321312', '', 'trash', 'closed', 'closed', '', '12321312__trashed', '', '', '2023-06-15 21:50:57', '2023-06-15 18:50:57', '', 0, 'http://realestate.000.pe/properties/12321312/', 0, 'property', '', 0),
(146, 4, '2023-06-15 21:11:59', '2023-06-15 18:11:59', '', '1232131', '', 'trash', 'closed', 'closed', '', '1232131__trashed', '', '', '2023-06-15 21:50:56', '2023-06-15 18:50:56', '', 0, 'http://realestate.000.pe/properties/1232131/', 0, 'property', '', 0) ;

#
# Конец содержимого данных таблицы `re_posts`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_term_relationships`
#

DROP TABLE IF EXISTS `re_term_relationships`;


#
# Структура таблицы `re_term_relationships`
#

CREATE TABLE `re_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_term_relationships`
#
INSERT INTO `re_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(1, 6, 0),
(1, 7, 0),
(1, 8, 0),
(2, 8, 0),
(3, 8, 0),
(5, 2, 0),
(10, 2, 0),
(10, 7, 0),
(10, 9, 0),
(11, 2, 0),
(12, 2, 0),
(13, 2, 0),
(14, 6, 0),
(14, 15, 0),
(16, 6, 0),
(16, 17, 0),
(17, 8, 0),
(18, 6, 0),
(18, 19, 0),
(20, 6, 0),
(20, 21, 0),
(21, 8, 0),
(21, 12, 0),
(22, 6, 0),
(22, 23, 0),
(24, 6, 0),
(24, 8, 0),
(24, 13, 0),
(24, 25, 0),
(25, 8, 0),
(26, 6, 0),
(26, 27, 0),
(28, 6, 0),
(28, 29, 0),
(30, 6, 0),
(30, 31, 0),
(34, 3, 0),
(35, 3, 0),
(36, 3, 0),
(37, 3, 0),
(38, 3, 0),
(39, 3, 0),
(40, 4, 0),
(41, 4, 0),
(42, 4, 0),
(43, 4, 0),
(50, 8, 0),
(53, 5, 0),
(53, 12, 0),
(54, 5, 0),
(55, 5, 0),
(55, 13, 0),
(55, 14, 0),
(55, 16, 0),
(55, 18, 0),
(55, 20, 0),
(55, 22, 0),
(55, 24, 0),
(55, 26, 0),
(56, 2, 0),
(59, 5, 0),
(60, 5, 0),
(61, 5, 0),
(62, 5, 0),
(72, 5, 0),
(72, 28, 0),
(73, 5, 0),
(74, 5, 0),
(76, 5, 0),
(77, 5, 0),
(78, 5, 0),
(79, 5, 0),
(80, 5, 0),
(81, 1, 0),
(81, 5, 0),
(82, 5, 0),
(85, 5, 0),
(86, 5, 0),
(89, 5, 0),
(90, 5, 0),
(92, 5, 0),
(93, 5, 0),
(94, 5, 0),
(95, 5, 0),
(96, 5, 0),
(97, 5, 0),
(98, 5, 0),
(99, 5, 0),
(100, 5, 0),
(101, 5, 0),
(102, 5, 0),
(103, 5, 0),
(104, 5, 0),
(106, 1, 0),
(106, 5, 0),
(107, 5, 0),
(110, 5, 0),
(111, 5, 0),
(112, 5, 0) ;
INSERT INTO `re_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(113, 5, 0),
(114, 5, 0),
(115, 5, 0),
(116, 5, 0),
(117, 5, 0),
(118, 5, 0),
(119, 5, 0),
(120, 5, 0),
(121, 5, 0),
(122, 5, 0),
(123, 5, 0),
(124, 5, 0),
(125, 5, 0),
(126, 5, 0),
(127, 5, 0),
(128, 5, 0),
(129, 5, 0),
(130, 5, 0),
(131, 5, 0),
(132, 5, 0),
(133, 5, 0),
(134, 5, 0),
(135, 5, 0),
(136, 5, 0),
(136, 28, 0),
(137, 5, 0),
(137, 22, 0),
(137, 24, 0),
(137, 26, 0),
(138, 5, 0),
(138, 30, 0),
(139, 5, 0),
(142, 5, 0),
(143, 5, 0),
(144, 5, 0),
(145, 5, 0),
(146, 5, 0) ;

#
# Конец содержимого данных таблицы `re_term_relationships`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_term_taxonomy`
#

DROP TABLE IF EXISTS `re_term_taxonomy`;


#
# Структура таблицы `re_term_taxonomy`
#

CREATE TABLE `re_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_term_taxonomy`
#
INSERT INTO `re_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 6),
(3, 3, 'nav_menu', '', 0, 6),
(4, 4, 'nav_menu', '', 0, 4),
(5, 5, 'language', 'a:3:{s:6:"locale";s:2:"uk";s:3:"rtl";i:0;s:9:"flag_code";s:2:"ua";}', 0, 12),
(6, 6, 'term_language', '', 0, 10),
(7, 7, 'term_translations', 'a:2:{s:2:"uk";i:1;s:2:"en";i:10;}', 0, 2),
(8, 8, 'language', 'a:3:{s:6:"locale";s:5:"en_US";s:3:"rtl";i:0;s:9:"flag_code";s:2:"us";}', 0, 3),
(9, 9, 'term_language', '', 0, 1),
(10, 10, 'category', '', 0, 0),
(12, 12, 'post_translations', 'a:2:{s:2:"en";i:21;s:2:"uk";i:53;}', 0, 2),
(13, 13, 'post_translations', 'a:2:{s:2:"uk";i:55;s:2:"en";i:24;}', 0, 2),
(14, 14, 'cities', '', 0, 1),
(15, 15, 'term_translations', 'a:1:{s:2:"uk";i:14;}', 0, 1),
(16, 16, 'features', '', 0, 1),
(17, 17, 'term_translations', 'a:1:{s:2:"uk";i:16;}', 0, 1),
(18, 18, 'features', '', 0, 1),
(19, 19, 'term_translations', 'a:1:{s:2:"uk";i:18;}', 0, 1),
(20, 20, 'features', '', 0, 1),
(21, 21, 'term_translations', 'a:1:{s:2:"uk";i:20;}', 0, 1),
(22, 22, 'features', '', 0, 1),
(23, 23, 'term_translations', 'a:1:{s:2:"uk";i:22;}', 0, 1),
(24, 24, 'features', '', 0, 1),
(25, 25, 'term_translations', 'a:1:{s:2:"uk";i:24;}', 0, 1),
(26, 26, 'features', '', 0, 1),
(27, 27, 'term_translations', 'a:1:{s:2:"uk";i:26;}', 0, 1),
(28, 28, 'cities', '', 0, 0),
(29, 29, 'term_translations', 'a:1:{s:2:"uk";i:28;}', 0, 1),
(30, 30, 'features', '', 0, 0),
(31, 31, 'term_translations', 'a:1:{s:2:"uk";i:30;}', 0, 1) ;

#
# Конец содержимого данных таблицы `re_term_taxonomy`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_termmeta`
#

DROP TABLE IF EXISTS `re_termmeta`;


#
# Структура таблицы `re_termmeta`
#

CREATE TABLE `re_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_termmeta`
#

#
# Конец содержимого данных таблицы `re_termmeta`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_terms`
#

DROP TABLE IF EXISTS `re_terms`;


#
# Структура таблицы `re_terms`
#

CREATE TABLE `re_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_terms`
#
INSERT INTO `re_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8', 0),
(2, 'Header', 'header', 0),
(3, 'Footer', 'footer', 0),
(4, 'social-footer', 'social-footer', 0),
(5, 'Українська', 'uk', 0),
(6, 'Українська', 'pll_uk', 0),
(7, 'pll_64848728986b2', 'pll_64848728986b2', 0),
(8, 'English', 'en', 0),
(9, 'English', 'pll_en', 0),
(10, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8-en', 0),
(12, 'pll_64848759efed3', 'pll_64848759efed3', 0),
(13, 'pll_6484890f1278a', 'pll_6484890f1278a', 0),
(14, 'Odessa', 'odessa', 0),
(15, 'pll_64889095b70ab', 'pll_64889095b70ab', 0),
(16, 'Swimming Pool', 'swimming-pool', 0),
(17, 'pll_64889183a9a25', 'pll_64889183a9a25', 0),
(18, '3 Stories', '3-stories', 0),
(19, 'pll_648891841752f', 'pll_648891841752f', 0),
(20, 'Central Cooling', 'central-cooling', 0),
(21, 'pll_6488918472e23', 'pll_6488918472e23', 0),
(22, 'Jog Path 2', 'jog-path-2', 0),
(23, 'pll_64889184d075b', 'pll_64889184d075b', 0),
(24, '2 Lawn', '2-lawn', 0),
(25, 'pll_6488918529794', 'pll_6488918529794', 0),
(26, 'Bike Path', 'bike-path', 0),
(27, 'pll_648891858335d', 'pll_648891858335d', 0),
(28, 'Mariupol', 'mariupol', 0),
(29, 'pll_6488c76c52236', 'pll_6488c76c52236', 0),
(30, 'terrasa', 'terrasa', 0),
(31, 'pll_648b41db40177', 'pll_648b41db40177', 0) ;

#
# Конец содержимого данных таблицы `re_terms`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_user_registration_sessions`
#

DROP TABLE IF EXISTS `re_user_registration_sessions`;


#
# Структура таблицы `re_user_registration_sessions`
#

CREATE TABLE `re_user_registration_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_key`),
  UNIQUE KEY `session_id` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_user_registration_sessions`
#

#
# Конец содержимого данных таблицы `re_user_registration_sessions`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_usermeta`
#

DROP TABLE IF EXISTS `re_usermeta`;


#
# Структура таблицы `re_usermeta`
#

CREATE TABLE `re_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_usermeta`
#
INSERT INTO `re_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'modern'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 're_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 're_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(17, 1, 're_dashboard_quick_press_last_post_id', '80'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(19, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(20, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(21, 1, 'nav_menu_recently_edited', '2'),
(22, 1, 're_persisted_preferences', 'a:3:{s:14:"core/edit-post";a:3:{s:26:"isComplementaryAreaVisible";b:1;s:12:"welcomeGuide";b:0;s:10:"openPanels";a:4:{i:0;s:11:"post-status";i:1;s:14:"featured-image";i:2;s:16:"discussion-panel";i:3;s:15:"page-attributes";}}s:9:"_modified";s:24:"2023-06-15T09:25:13.299Z";s:17:"core/edit-widgets";a:2:{s:26:"isComplementaryAreaVisible";b:1;s:12:"welcomeGuide";b:0;}}'),
(23, 1, 're_user-settings', 'libraryContent=browse&editor=tinymce'),
(24, 1, 're_user-settings-time', '1686649962'),
(25, 1, 'enable_custom_fields', '1'),
(26, 1, 'closedpostboxes_acf-field-group', 'a:1:{i:0;s:23:"acf-field-group-options";}'),
(27, 1, 'metaboxhidden_acf-field-group', 'a:1:{i:0;s:7:"slugdiv";}'),
(28, 1, 'pll_filter_content', ''),
(29, 1, 'closedpostboxes_property', 'a:0:{}'),
(30, 1, 'metaboxhidden_property', 'a:1:{i:0;s:7:"slugdiv";}'),
(31, 1, 'meta-box-order_property', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:56:"ml_box,submitdiv,citiesdiv,tagsdiv-features,postimagediv";s:6:"normal";s:43:"acf-group_64847c2f4b608,postexcerpt,slugdiv";s:8:"advanced";s:0:"";}'),
(32, 1, 'screen_layout_property', '2'),
(51, 1, 'manageedit-acf-post-typecolumnshidden', 'a:1:{i:0;s:7:"acf-key";}'),
(52, 1, 'acf_user_settings', 'a:1:{s:19:"post-type-first-run";b:1;}'),
(53, 1, 'closedpostboxes_acf-post-type', 'a:0:{}'),
(54, 1, 'metaboxhidden_acf-post-type', 'a:2:{i:0;s:21:"acf-advanced-settings";i:1;s:7:"slugdiv";}'),
(78, 4, 'nickname', 'user'),
(79, 4, 'first_name', ''),
(80, 4, 'last_name', ''),
(81, 4, 'description', ''),
(82, 4, 'rich_editing', 'true'),
(83, 4, 'syntax_highlighting', 'true'),
(84, 4, 'comment_shortcuts', 'false'),
(85, 4, 'admin_color', 'fresh'),
(86, 4, 'use_ssl', '0'),
(87, 4, 'show_admin_bar_front', 'true'),
(88, 4, 'locale', 'ru_RU'),
(89, 4, 're_capabilities', 'a:1:{s:10:"subscriber";b:1;}'),
(90, 4, 're_user_level', '0'),
(91, 4, 'default_password_nag', ''),
(93, 4, 're_dashboard_quick_press_last_post_id', '139'),
(94, 4, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(98, 1, 'session_tokens', 'a:1:{s:64:"ebe7719345b44ef43be8f4d29002251211f8220c1d8751020f8f27a7a28c3195";a:4:{s:10:"expiration";i:1688062573;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:80:"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0";s:5:"login";i:1686852973;}}') ;

#
# Конец содержимого данных таблицы `re_usermeta`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_users`
#

DROP TABLE IF EXISTS `re_users`;


#
# Структура таблицы `re_users`
#

CREATE TABLE `re_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_users`
#
INSERT INTO `re_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BGPAPPg4nyuhME.nOmFl5yzcYjU4uD.', 'admin', 'shyshkinandrey06@gmail.com', 'http://realestate.000.pe', '2023-05-29 09:20:15', '', 0, 'admin'),
(4, 'user', '$P$BvUQ0ZLmXZ5fBvf0iTHqFH76l/BnRz/', 'user', 'name@name.name', '', '2023-06-15 17:30:01', '1686850202:$P$BRQOkhmZ.OUiojthrtcbo2Xdqw632./', 0, 'user') ;

#
# Конец содержимого данных таблицы `re_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

